Ext.define('MyApp.view.forms.Contact', {
    extend: 'Ext.form.Panel',

    xtype: 'contact',

    frame: true,
    margin: '110 300 110 300',

    defaults:{
         xtype: 'textfield',
         allowBlank: false
     },

    fieldDefaults:{
        labelAlign: 'top',
        afterLabelTextTpl: [
            '<span style="color:red;font-weight:bold" data-qtip="Required">*</span>'
        ]
    },

    items: [{
        xtype: 'container',
        layout: 'hbox',
        items:[{
            xtype: 'textfield',
            fieldLabel: 'First Name',
            name: 'first',
            allowBlank: false,
            margin: '0 20 0 0',
            msgTarget: Ext.supports.Touch ? 'side' : 'qtip'
        }, {
            xtype: 'textfield',
            fieldLabel: 'Last Name',
            name: 'last',
            allowBlank: false,
            margin: '0 0 0 20',
            msgTarget: 'title'
        }]  
    }, {
        fieldLabel: 'Email Address',
        name: 'email',
        vtype: 'email',
        anchor: '50%',
        msgTarget: 'side'
    }, {
        fieldLabel: 'Subject',
        name: 'sub',
        anchor: '50%',
        msgTarget: 'under'
    }, {
        xtype: 'container',
        layout: 'hbox',
        items: [{
            xtype: 'textareafield',
            fieldLabel: 'Message',
            name: 'msg',
            allowBlank: false,
            width:280,
            margin: '0 20 0 0',
            msgTarget: 'error'
        },{
            xtype: 'tbtext', 
            id: 'error',
            margin: '60 0 0 0' 
        }]
    }],

    buttons: [{
        text: 'Clear',
        handler: function(button) {
            button.up('form').getForm().clearInvalid();
        }
    },{
        text: 'Reset',
        handler: function(button) {
            button.up('form').getForm().reset();
        }
    },{
        text: 'Send',
        handler: function(button) {
           var form = button.up('form').getForm();
           var valid = form.isValid();
           if(valid == false) {
               var fields = form.getFields();
               var errors = [];
               fields.each(function(field) {
                    Ext.Array.forEach(field.getErrors(), function(error) {
                        errors.push({name: field.getFieldLabel(), error: error});
                    });
                });
               var st = '';
               Ext.Array.forEach(errors, function(error) {
                    st = st + Ext.encode(error) + '<br />'+'<br />';
                } );   
               Ext.Msg.alert("Errors",st) ;
           }
        }
    }]
});