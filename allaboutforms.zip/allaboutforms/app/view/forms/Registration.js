Ext.define('MyApp.view.forms.Registration', {
    extend: 'Ext.form.Panel',

    xtype: 'registration',

    frame: true,
    margin: 170
});    