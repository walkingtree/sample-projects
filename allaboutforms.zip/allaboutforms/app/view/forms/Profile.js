/**
 * Demonstrates a simple profile form.
 */
Ext.define('MyApp.view.forms.Profile', {
    extend: 'Ext.form.Panel',

    xtype: 'profile',

    frame: true,
    margin: 20,

    items: [{
        xtype: 'textfield',
        fieldLabel: 'First Name',
        name: 'first',
        value: 'George'
    }, {
        xtype: 'textfield',
        fieldLabel: 'Last Name',
        name: 'last',
        value: 'Paul'
    }, {
        xtype: 'combo',
        fieldLabel: 'Profession',
        emptyText: 'Select',
        name: 'profession',
        store: ['Musician', 'Engineer', 'Civil Servant', 'Doctor', 'Teacher', 'Architect', 'Banker', 'Environmentalist', 'Actor']
    }, {
        xtype: 'datefield',
        fieldLabel: 'Date of Birth',
        name: 'dob',
        value: new Date(1965, 10, 11)
    }, {
        xtype: 'fieldcontainer',
        fieldLabel: 'Postal Address',
        layout: 'hbox',
        items: [{
            xtype: 'textfield',
            name: 'city',
            emptyText: 'City',
            flex: .5
        }, {
            xtype: 'tbtext',
            text: ',&nbsp;'
        }, {
            xtype: 'textfield',
            name: 'state',
            emptyText: 'State',
            flex: .5
        }, {
            xtype: 'tbtext',
            text: ',&nbsp;'
        }, {
            xtype: 'textfield',
            name: 'code',
            emptyText: 'Code',
            width: 150
        }]
    }, {
        xtype: 'checkboxfield',
        boxLabel: 'Married',
        name: 'married',
        checked: false
    }, {
        xtype: 'radiogroup',
        fieldLabel: 'Sex',
        columns: 1,
        items: [{
            boxLabel: 'Male',
            name: 'sex',
            checked: true
        }, {
            boxLabel: 'Female',
            name: 'sex'
        }]
    }, {
        xtype: 'textfield',
        fieldLabel: 'Phone Number',
        emptyText: 'xxx-xxx-xxxx',
        name: 'phone'
    }, {
        xtype: 'textfield',
        fieldLabel: 'Email Address',
        emptyText: 'ex: me@somewhere.com',
        name: 'email',
        vtype: 'email'
    }, {
        xtype: 'htmleditor',
        fieldLabel: 'Brief Biography',
        name: 'bio',
        height: 100
    }],

    buttons: [{
        text: 'Send',
        handler: function(button) {
            button.up('form').submit({
                url: 'fake.php',
                success: function(form, action) {
                    Ext.Msg.alert('Form Saved');
                },
                failure: function(form, action) {
                    Ext.Msg.alert('Save Failed');
                }
            });
        }
    }, {
        text: 'Show Field Data',
        handler: function(button) {
            var s = '';
            var fields = button.up('form').getForm().getFields().items;
            Ext.Array.forEach(fields, function(field) {
                if (field.name) {
                    s += field.name + ' = ' + field.value + '<br/>';
                }
            });
            Ext.Msg.alert('Field=Value',s);
        }
    }]
});