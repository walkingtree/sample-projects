Ext.define('MyApp.view.forms.BugTracker', {
	extend: 'Ext.form.Panel',

	xtype: 'bugtracker',

	frame: true,
	margin: 10
});