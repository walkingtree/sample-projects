Ext.define('MyApp.view.forms.FormLoadRecord', {
	extend: 'Ext.window.Window',

	xtype: 'formloadrecord',

	resizable: false,
	bodyPadding: 8,
	modal: true,

	layout: 'fit',

	items: [{
		xtype: 'form',
		items: [{
			xtype: 'textfield',
			fieldLabel: 'Name',
			name: 'name',
			allowBlank: false
		}, {
			xtype: 'textfield',
			fieldLabel: 'Email',
			name: 'email',
			allowBlank: false,
			vtype: 'email'
		}, {
			xtype: 'textfield',
			fieldLabel: 'Phone',
			name: 'phone',
			allowBlank: false,
			regex: /^\d{3}-\d{3}-\d{4}$/
		}],
		buttons: [{
			text: 'Model Save',
			handler: 'onModelSave'
		},{
			text: 'Form Submit',
			handler: 'onFormSubmit'
		}]
	}]
});