Ext.define('MyApp.view.forms.Checkout', {
	extend: 'Ext.form.Panel',

	xtype: 'checkout',

	frame: true,
	margin: '10 180 10 180',

	layout: 'anchor', //default

	fieldDefaults: {
		labelAlign: 'right',
		msgTarget: 'qtip',
		anchor: '100%'
	},

	defaultType: 'fieldset',

	items: [{
		title: 'Contact Information',
		collapsible: true,
		layout: 'column',
		defaults: {
			xtype: 'textfield',
			columnWidth: 0.5,
			margin: '0 0 6 0'
		},
		items: [{
			fieldLabel: 'First Name',
			emptyText: 'required',
			name: 'firstName',
			allowBlank: false
		}, {
			fieldLabel: 'Last Name',
			emptyText: 'required',
			name: 'lastName',
			allowBlank: false
		}, {
			fieldLabel: 'Email Address',
			emptyText: 'me@somewhere.com',
			name: 'email',
			vtype: 'email',
			allowBlank: false
		}, {
			fieldLabel: 'Phone Number',
			emptyText: 'xxx-xxx-xxxx',
			name: 'phone',
			maskRe: /[\d\-]/,
			regex: /^\d{3}-\d{3}-\d{4}$/,
			regexText: 'Must be in the format xxx-xxx-xxxx'
		}]
	}, {
		title: 'Mailing Address',
		checkboxToggle: true,
		layout: 'form', //Labels automatically size to match the widest label
		items: [{
			xtype: 'textfield', //Items stretch to fill the container width
			fieldLabel: 'Street Address',
			name: 'streetAdd',
			allowBlank: false
		}, {
			xtype: 'fieldcontainer', //Items stretch to fill the container width
			fieldLabel: 'City, State, PIN',
			defaults:{
				xtype: 'textfield',
				margin: '0 6 6 0'
			},
			layout: 'hbox',
			items: [{
				name: 'mailCity',
				emptyText: 'city',
				width: 200,
				allowBlank: false
			}, {
				name: 'mailState',
				emptyText: 'state',
				width: 175,
				allowBlank: false
			}, {
				name: 'mailCode',
				emptyText: 'pin',
				width: 150,
				maskRe: /[\d\-]/,
				regex: /^\d{5}(\-\d{4})?$/,
				regexText: 'Must be in the format xxxxx or xxxxx-xxxx',
				allowBlank: false
			}]
		}, {
			xtype: 'combobox', //Items stretch to fill the container width
			fieldLabel: 'Country',
			name: 'mailCountry',
			bind: {
				store: '{countries}'
			},
			forceSelection: true,
			displayField: 'cntry',
			valueField: 'id',
			typeAhead: true,
			queryMode: 'local',
			allowBlank: false
		}]
	}]
});	