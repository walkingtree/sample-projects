Ext.define('MyApp.view.forms.Application', {
	extend: 'Ext.form.Panel',

	xtype: 'application',

	frame: true,
	margin: 10,
	scrollable: true
});