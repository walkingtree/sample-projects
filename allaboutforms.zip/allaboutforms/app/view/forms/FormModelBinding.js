Ext.define('MyApp.view.forms.FormModelBinding', {
	extend: 'Ext.window.Window',

	xtype: 'formmodelbinding',

	resizable: false,
	bodyPadding: 8,
	modal: true,

	layout: 'fit',

	items: [{
		xtype: 'form',
		items: [{
			xtype: 'textfield',
			fieldLabel: 'Name',
			bind: {
				value: '{editDetails.name}'
			}
		}, {
			xtype: 'textfield',
			fieldLabel: 'Email',
			bind: {
				value: '{editDetails.email}'
			}
		}, {
			xtype: 'textfield',
			fieldLabel: 'Phone',
			bind: {
				value: '{editDetails.phone}'
			}

		}],
		buttons: [{
			text: 'Save',
			handler: 'onSave'
		}, {
			text: 'Cancel',
			handler: 'onCancel'
		}]
	}]
});