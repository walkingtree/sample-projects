/**
 * This class is the view model for the Main view of the application.
 */
Ext.define('MyApp.view.main.MainModel', {
    extend: 'Ext.app.ViewModel',

     requires: [
        'MyApp.model.Position',
        'MyApp.model.Country',
        'MyApp.model.User'
    ],

    alias: 'viewmodel.main',

    data: {
        name: 'Forms'
    },

    stores: {
        positions: {
            model: 'MyApp.model.Position',
            autoLoad: true
        },
        countries: {
            model: 'MyApp.model.Country',
            autoLoad: true
        },
        users: {
            model: 'MyApp.model.User',
            autoLoad: true,
            proxy: {
                type: 'ajax',
                url: 'resources/data/Users.json'
            }
        },  
        people: {
            model: 'MyApp.model.User',
            autoLoad: true,
            proxy: {
                type: 'ajax',
                url: 'resources/data/People.json'
            }
        }
        
    }
});
