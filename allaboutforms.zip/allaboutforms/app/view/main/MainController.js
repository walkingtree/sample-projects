/**
 * This class is the controller for the main view for the application. It is specified as
 * the "controller" of the Main view class.
 *
 * TODO - Replace this content of this view to suite the needs of your application.
 */
Ext.define('MyApp.view.main.MainController', {
    extend: 'Ext.app.ViewController',

    alias: 'controller.main',

    requires:[
		'MyApp.view.forms.FormModelBinding',
		'MyApp.view.forms.FormLoadRecord'
	],

	onItemSelected: function(sender, record) {
		Ext.create("MyApp.view.forms.FormModelBinding", {
			viewModel: {
				data: {
					editDetails: record
				}
			},
			title: 'Edit Form',
			autoShow: true
		});
	},

	onUpdate: function(button) {
		var win = Ext.create("MyApp.view.forms.FormLoadRecord", {
			title: 'Edit Form',
			autoShow: true
		});
	}	

});
