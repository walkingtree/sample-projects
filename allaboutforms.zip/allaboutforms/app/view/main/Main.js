/**
 * This class is the main view for the application. It is specified in app.js as the
 * "mainView" property. That setting automatically applies the "viewport"
 * plugin causing this view to become the body element (i.e., the viewport).
 *
 * TODO - Replace this content of this view to suite the needs of your application.
 */
Ext.define('MyApp.view.main.Main', {
    extend: 'Ext.tab.Panel',
    xtype: 'app-main',

    requires: [
        'Ext.plugin.Viewport',
        'Ext.window.MessageBox',
        'MyApp.view.main.MainController',
        'MyApp.view.main.MainModel',
        'MyApp.view.forms.Profile',
        'MyApp.view.forms.Application',
        'MyApp.view.forms.BugTracker',
        'MyApp.view.forms.Registration',
        'MyApp.view.forms.Contact',
        'MyApp.view.forms.Checkout',
        'MyApp.view.main.List'
    ],

    controller: 'main',
    viewModel: 'main',

    ui: 'navigation',

    headerPosition: 'left',
    tabBarHeaderPosition: 1,
    titleRotation: 0,
    tabRotation: 0,
    removePanelHeader: false,

    header: {
        layout: {
            align: 'stretchmax'
        },
        title: {
            bind: {
                text: '{name}'
            },
            flex: 0
        },
        iconCls: 'fa fa-pencil-square-o'
    },

    tabBar: {
        flex: 1,
        layout: {
            align: 'stretch',
            overflowHandler: 'none'
        }
    },

    defaults: {
        bodyPadding: 20,
        tabConfig: {
            iconAlign: 'left',
            textAlign: 'left'
        }
    },

    items: [{
        xtype: 'profile',
        title: 'Profile Form'
    }, {
        html: 'Employment Application Form',
        title: 'Employment Application Form'
    }, {
        html: 'Bug Tracker Form',
        title: 'Bug Tracker Form'
    }, {
        html: 'Registration Form',
        title: 'Registration Form'
    }, {
        xtype: 'contact',
        title: 'Contact Form'
    }, {
        xtype: 'checkout',
        title: 'Checkout Form'
    }, {
        xtype: 'container',
        title: 'Grid Editing Form',
        items: [{
            xtype: 'list',
            title: 'Users',
            reference: 'userslist',
            bind: {
                store: '{users}'
            },
            dockedItems: [{
                xtype: 'toolbar',
                docked: 'top',
                items: [{
                    xtype: 'button',
                    text: 'Update',
                    margin: 5,
                    handler: 'onUpdate'
                }]
            }]
        }, {
            xtype: 'list',
            title: 'Personnel',
            bind: {
                store: '{people}'
            },
            dockedItems: [{
                xtype: 'toolbar',
                docked: 'top',
                items: [{
                    xtype: 'tbtext',
                    text: 'Select Record to Edit',
                    margin: 5
                }]
            }],
            listeners: {
                select: 'onItemSelected'
            }
        }]
    }]
});