Ext.define('MyApp.model.User', {
    extend: 'Ext.data.Model',
    fields: [{
        name: 'name', 
        type: 'string',
        validators: [{
           type: 'presence',
           message: 'Name is a mandatory field'
        }]
    },{
        name: 'email', 
        type: 'string',
        validators:[{
            type: 'presence',
            message: 'Email is a mandatory field'
        },{
            type: 'email',
            message: 'Email address is not in a valid format'
        }]
    },{
        name: 'phone',
        type: 'string',
        validators:[{
            type: 'format',
            matcher: /^\d{3}-\d{3}-\d{4}$/,
            message: 'Phone Number contains invalid characters'
        }]
    }]
});