Ext.define('MyApp.model.Position', {
    extend: 'Ext.data.Model',

    proxy: {
        type: 'ajax',
        url: 'resources/data/Position.json',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    }
});