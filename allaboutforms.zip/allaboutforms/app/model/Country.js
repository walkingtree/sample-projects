Ext.define('MyApp.model.Country', {
    extend: 'Ext.data.Model',

    proxy: {
        type: 'ajax',
        url: 'resources/data/Country.json',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    }
});