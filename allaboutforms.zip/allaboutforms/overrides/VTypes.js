Ext.define('MyApp.overrides.form.field.VTypes', {
	  override: 'Ext.form.field.VTypes',

	  password: function(value, field) {
	  		var prevSibling = field.previousSibling();
            return (value === prevSibling.getValue()) ? true : false
      },

      passwordText: 'Passwords do not match.'
});
   

