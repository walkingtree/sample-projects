import 'package:flutter/material.dart';

class MovieTile extends StatefulWidget {
  final String movieName;
  MovieTile({@required this.movieName});

  @override
  _MovieTileState createState() => _MovieTileState();
}

class _MovieTileState extends State<MovieTile> {
  bool _isFavorite = false;

  void _toggleFavorite() {
    setState(() {
      _isFavorite = !_isFavorite;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(
        widget.movieName,
        style: (_isFavorite)
            ? TextStyle(color: Colors.white)
            : TextStyle(color: Colors.white54),
      ),
      trailing: FavoriteIcon(
        isFavorite: _isFavorite,
        onPressedHandler: _toggleFavorite,
      ),
    );
  }
}

class FavoriteIcon extends StatelessWidget {
  final bool isFavorite;
  final Function onPressedHandler;

  FavoriteIcon({
    @required this.isFavorite,
    @required this.onPressedHandler,
  });

  @override
  Widget build(BuildContext context) {
     return IconButton(
        icon: (isFavorite)
            ? Icon(
                Icons.favorite,
                color: Colors.red,
              )
            : Icon(
                Icons.favorite_border,
                color: Colors.red,
              ),
            onPressed: onPressedHandler,
     );
  }
}
