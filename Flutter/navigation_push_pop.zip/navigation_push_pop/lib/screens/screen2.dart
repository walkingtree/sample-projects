import 'package:flutter/material.dart';
import './screen3.dart';

class Screen2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //Adds back button
      appBar: AppBar(
        title: Text('Navigation'),
      ),

      // On tap allows navigation to Screen3
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.arrow_forward),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => Screen3(),
            ),
          );
        },
      ),
      
      body: Container(
        child: Center(
          child: Text('Screen 2',
              style: Theme.of(context).textTheme.bodyText1,
             ),
        ),
      ),
    );
  }
}
