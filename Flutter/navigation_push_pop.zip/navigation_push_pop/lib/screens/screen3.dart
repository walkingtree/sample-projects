import 'package:flutter/material.dart';

class Screen3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Adds back button. User can go back to Screen2 using this button
      appBar: AppBar(
        title: Text('Navigation'),
      ),

      //Optionally, user can go back to Screen2 via this button
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.arrow_back),
        onPressed: () {
          Navigator.pop(context);
        },
      ),

      body: Container(
        child: Center(
          child: Text(
            'Screen 3',
            style: Theme.of(context).textTheme.bodyText1,
          ),
        ),
      ),
    );
  }
}
