import 'package:flutter/material.dart';
import './screen2.dart';

class Screen1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Adds back button to go back
      appBar: AppBar(
        title: Text('Navigation'),
      ),

      // On tap, it allows navigation to Screen2
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.arrow_forward),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => Screen2(),
            ),
          );
        },
      ),
      
      body: Container(
        child: Center(
          child: Text(
            'Screen 1',
             style: Theme.of(context).textTheme.bodyText1,
          ),
        ),
      ),
    );
  }
}
