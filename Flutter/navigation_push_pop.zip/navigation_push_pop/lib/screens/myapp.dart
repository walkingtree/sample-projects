import 'package:flutter/material.dart';
import './screen1.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Navigation',
      theme: ThemeData(
                brightness: Brightness.dark,
                primarySwatch: Colors.blueGrey,
                textTheme: TextTheme(
                  bodyText1: TextStyle(
                      fontSize: 24.0,
                      fontWeight: FontWeight.bold,
                  ),
                ),
      ),
      home: Screen1(),
    );
  }
}
