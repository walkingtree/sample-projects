import 'package:flutter/material.dart';
import './screens/screen1.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Simple Navigation',
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: Colors.pink,
        textTheme: TextTheme(
          bodyText1: TextStyle(fontSize: 30.0, fontWeight: FontWeight.bold), 
        ),
      ),
      //Initial Route
      home: Screen1(),
    );
  }
}

