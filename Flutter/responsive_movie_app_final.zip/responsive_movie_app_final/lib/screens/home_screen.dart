import 'package:flutter/material.dart';

import 'no_drawer_list.dart';
import 'main_drawer.dart';
import 'movie_listview.dart';

class HomeScreen extends StatelessWidget {
  static final routeName = '/homeScreen';
  static const int tabletBreakpoint = 600;

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final bool isPortrait = mediaQuery.orientation == Orientation.portrait;
    //The lesser of the magnitudes of the width and the height.
    double shortestSide = mediaQuery.size.shortestSide;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Movies',
        ),
      ),
      drawer: (isPortrait && shortestSide < tabletBreakpoint)
      // Mobile
          ? MainDrawer()
      // Tablet and Landscape
          : null,
      // body: LoginScreen(),
      body: (isPortrait && shortestSide < tabletBreakpoint)
         // Mobile
          ? MovieListView()
         // Tablet and Landscape
          : Row(
        children: [
          Expanded(child: NoDrawerList(), flex: 1),
          Expanded(
            child: MovieListView(),
            flex: 2,
          ),
        ],
      ),
    );
  }
}
