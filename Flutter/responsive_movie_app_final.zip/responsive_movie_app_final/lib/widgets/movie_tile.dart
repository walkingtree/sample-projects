import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import './../providers/movie_provider.dart';
import './../model/movie_model.dart';

class MovieTile extends StatelessWidget {
  static const int tabletBreakpoint = 600;
  final int movieIndex;

  MovieTile({
    @required this.movieIndex,
  });

  @override
  Widget build(BuildContext context) {
    final MediaQueryData mediaQuery = MediaQuery.of(context);

    return Consumer<Movies>(
      builder: (context, movies, child) {
        MovieModel movie = movies.movies[movieIndex];
        return ListTile(
          title: Text(
            movie.movieName,
            style: (movie.isFavorite)
                ? TextStyle(color: Colors.white)
                : TextStyle(color: Colors.white54),
          ),
          trailing: (mediaQuery.size.width < tabletBreakpoint)
              ? IconButton(
                  icon: (movie.isFavorite)
                      ? Icon(
                          Icons.favorite,
                          color: Colors.red,
                        )
                      : Icon(
                          Icons.favorite_border,
                          color: Colors.red,
                        ),
                  onPressed: () {
                    Provider.of<Movies>(context, listen: false)
                        .updateFavorite(movie);
                  },
                )
              : AspectRatio(
                  aspectRatio: 3,
                  child:
                      Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                    IconButton(
                      icon: (movie.isFavorite)
                          ? Icon(
                              Icons.favorite,
                              color: Colors.red,
                              size: 28.0,
                            )
                          : Icon(
                              Icons.favorite_border,
                              color: Colors.red,
                              size: 28.0,
                            ),
                      onPressed: () {
                        Provider.of<Movies>(context, listen: false)
                            .updateFavorite(movie);
                      },
                    ),
                    SizedBox(width: 10.0),
                    IconButton(
                        icon: Icon(
                          Icons.play_arrow,
                          size: 30.0,
                        ),
                        color: Theme.of(context).errorColor,
                        onPressed: () {}),
                  ]),
                ),
        );
      },
    );
  }
}
