import 'package:flutter/material.dart';
import '../models/user_model.dart';

class UserScreen extends StatelessWidget {
  final UserModel user;

  UserScreen(this.user);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'User',
        ),
      ),
      body: Container(
        alignment: Alignment.center,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
             //TODO 6: Display the User name.
              style: Theme.of(context).textTheme.bodyText2,
            ),
            Text(
              //TODO 7: Display the City name.
              style: Theme.of(context).textTheme.bodyText2,
            ),
            Text(
              //TODO 8: Display the Company name.
              style: Theme.of(context).textTheme.bodyText2,
            ),
          ],
        ),
      ),
    );
  }
}
