import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'dart:convert';
// import './user_screen.dart';
// import '../models/user_model.dart';
// import '../services/api_service.dart';


class HomeScreen extends StatefulWidget {
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  
  final String baseUrl = 'https://jsonplaceholder.typicode.com';

  Future getUser() async {
    //TODO 1: Make a network request.

    //TODO 2: Parse the JSON string and print user name, city and company name.

    //TODO 4: Create a simplified UserModel object.

    //TODO 5: Navigate to the UserScreen, passing the UserModel object to it.

    //TODO 10: Modify this code to user the api service.
  }
   
  Future getUsers() async {}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Networking',
          style: TextStyle(
            color: Colors.white,
            fontSize: 28.0,
          ),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            RaisedButton(
              child: Text(
                'Get User',
                style: Theme.of(context).textTheme.bodyText1,
              ),
              onPressed: getUser,
            ),
            SizedBox(
              height: 20.0,
            ),
            RaisedButton(
              child: Text(
                'Get Users',
                style: Theme.of(context).textTheme.bodyText1,
              ),
              onPressed: getUsers,
            ),
          ],
        ),
      ),
    );
  }
}
