import 'package:flutter/material.dart';

class MovieTile extends StatelessWidget {
  final String movieName;

  MovieTile({@required this.movieName});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(
        movieName,
      ),
      trailing: FavoriteIcon(),
    );
  }
}

class FavoriteIcon extends StatefulWidget {
  @override
  _FavoriteIconState createState() => _FavoriteIconState();
}

class _FavoriteIconState extends State<FavoriteIcon> {
  bool _isFavorite = false;

  @override
  Widget build(BuildContext context) {
    return (_isFavorite)
        ? IconButton(
            icon: Icon(
              Icons.favorite,
              color: Colors.red,
            ),
            onPressed: () {
              setState(() {
                _isFavorite = !_isFavorite;
              });
            },
          )
        : IconButton(
            icon: Icon(
              Icons.favorite_border,
              color: Colors.red,
            ),
            onPressed: () {
              setState(() {
                _isFavorite = !_isFavorite;
              });
            },
          );
  }
}
