import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'util/movie_theme.dart';

import './movie_listview.dart';
import './main_drawer.dart';
import './model/movie.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<Movies>(
      create: (context) => Movies(),
      child: MaterialApp(
        title: 'Flutter Demo',
        theme: movieTheme,
        //TODO3: Add Routes Table for MyHomePage and FavoriteMovies
      ),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Movies',
        ),
      ),
      drawer: MainDrawer(),
      body: MovieListView(),
    );
  }
}
