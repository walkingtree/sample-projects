import 'package:flutter/foundation.dart';

class MovieModel {
  String movieId;
  String movieName;
  bool isFavorite;
  String posterUrl;

  MovieModel(
      {@required this.movieId,
      @required this.movieName,
      @required this.posterUrl,
      this.isFavorite = false});

  void toggleFavorite() {
    isFavorite = !isFavorite;
  }
}

class Movies extends ChangeNotifier {
  final List<MovieModel> _movies = [
    MovieModel(
      movieId: 'M1',
      movieName: 'The Godfather',
      posterUrl:
          'https://lunkiandsika.files.wordpress.com/2011/11/the-godfather-alternative-poster-1972-01.png',
    ),
    MovieModel(
      movieId: 'M2',
      movieName: 'The Notebook',
      posterUrl: 'http://www.impawards.com/2004/posters/notebook.jpg',
    ),
  ];

  List<MovieModel> get movies {
    return _movies;
  }

  int get movieCount {
    return _movies.length;
  }

  void updateFavorite(MovieModel movieItem) {
    movieItem.toggleFavorite();
    notifyListeners();
  }

  //TODO1: Write favoriteMovies getter to return list of favorite movies
 
  //TODO2: Write favCount getter to return number of favorite movies
}
