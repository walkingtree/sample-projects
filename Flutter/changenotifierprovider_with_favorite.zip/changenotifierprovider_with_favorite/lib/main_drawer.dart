import 'package:flutter/material.dart';

class MainDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      elevation: 2.0,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.black87,
        ),
        child: Column(
          children: <Widget>[
            Container(
              padding: EdgeInsets.only(
                left: 20.0,
                top: 40.0,
              ),
              width: double.infinity,
              height: 100.0,
              color: Colors.red[600],
              child: Text(
                'Movies',
                style: Theme.of(context).textTheme.headline1,
              ),
            ),
            DrawerListTile(
                name: 'Home',
                icon: Icons.home,
                onTapHandler: () {
                  //TODO8: Add Route to navigate to home screen.
                }),
            DrawerListTile(
                name: 'Favorites',
                icon: Icons.favorite,
                onTapHandler: () {
                  //TODO9: Add Route to navigate to Favorite Movies screen.
                }),
          ],
        ),
      ),
    );
  }
}

class DrawerListTile extends StatelessWidget {
  final String name;
  final IconData icon;
  final Function onTapHandler;

  const DrawerListTile({
    this.name,
    this.icon,
    this.onTapHandler,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTapHandler,
      child: ListTile(
        contentPadding: EdgeInsets.fromLTRB(15.0, 20.0, 20.0, 0.0),
        leading: Icon(
          icon,
          color: Colors.red[600],
          size: 30.0,
        ),
        title: Text(
          name,
          style: Theme.of(context)
              .textTheme
              .bodyText2
              .copyWith(color: Theme.of(context).accentColor),
        ),
        //TODO10: If name = 'Favorites' then add Text widget to show number of favorite movies. HINT: Use Consumer widget to get the count of favorite movies.
      ),
    );
  }
}
