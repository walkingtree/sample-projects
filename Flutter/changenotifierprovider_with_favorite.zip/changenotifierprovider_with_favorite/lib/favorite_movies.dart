import 'package:flutter/material.dart';

class FavoriteMovies extends StatelessWidget {
  static final routeName = '/favoriteMovies';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text('Favorites'),
      ),
      body: FavoritePage(),
    );
  }
}

class FavoritePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    //TODO4: Write code to show FavoritesGrid widget or NoFavorite widget based on there are any favorite movies or not.
  }
}

class FavoritesGrid extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(10.0),
      //TODO5: Set itemCount equal to number of favorite movies
      itemBuilder: (context, index) => FavoriteGridItem(
        favMovieIndex: index,
      ),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 2 / 3,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
      ),
    );
  }
}

class FavoriteGridItem extends StatelessWidget {
  final int favMovieIndex;

  FavoriteGridItem({@required this.favMovieIndex});

  @override
  Widget build(BuildContext context) {
    // final movies = Provider.of<Movies>(context, listen: false);
    return ClipRRect(
      borderRadius: BorderRadius.circular(5),
      child: GridTile(
        child: Image.network(
          //TODO6: Pass the favorite movie's posterUrl
          fit: BoxFit.cover,
        ),
        footer: GridTileBar(
          backgroundColor: Colors.black87,
          trailing: IconButton(
            icon: Icon(
              Icons.play_arrow,
              size: 22.0,
            ),
            color: Theme.of(context).accentColor,
            onPressed: () {},
          ),
          leading: Text(
            //TODO7: Pass the favorite movie's movieName
            style: TextStyle(
              fontSize: 13.0,
            ),
          ),
          // ]),
        ),
      ),
    );
  }
}

class NoFavorite extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Nothing to Show',
        style:
            Theme.of(context).textTheme.subtitle1.copyWith(color: Colors.black),
      ),
    );
  }
}
