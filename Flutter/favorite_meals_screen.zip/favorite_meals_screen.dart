import 'package:flutter/material.dart';
import '../../models/meal.dart';
import '../../widgets/main_drawer.dart';

class FavoriteMealsScreen extends StatelessWidget {
  static const routeName = '/favoriteMealsScreen';

  // List containing the favorite meals
  final List<Meal> favoriteMeals;

  FavoriteMealsScreen(this.favoriteMeals);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Favorite Meals'),
      ),
      drawer: MainDrawer(),
      body: (favoriteMeals.isEmpty)
          ? Center(
              child: Text(
                'You have no favorites!',
                style: Theme.of(context).textTheme.bodyText1,
              ),
            )
          : ListView.builder(
              itemBuilder: (ctx, index) {
                return Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Stack(children: [
                    Container(
                      height: 200.0,
                      width: 200.0,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15.0),
                        color: Colors.red,
                      ),
                      alignment: Alignment.center,
                      child: CircleAvatar(
                        radius: 85.0,
                        backgroundImage: NetworkImage(
                          favoriteMeals[index].imageUrl,
                        ),
                      ),
                    ),
                    Positioned(
                        right: 0.0,
                        left: 185.0,
                        child: Container(
                          height: 220.0,
                          width: double.infinity,
                          padding: EdgeInsets.all(5.0),
                          color: Theme.of(context).primaryColor,
                          child: Column(
                            children: [
                              Text(
                                favoriteMeals[index].title,
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyText2
                                    .copyWith(color: Colors.black),
                                softWrap: true,
                              ),
                              SizedBox(
                                height: 15,
                              ),
                              Row(
                                children: <Widget>[
                                  Icon(
                                    Icons.brightness_1,
                                    size: 8.0,
                                    color: Colors.red[900],
                                  ),
                                  SizedBox(
                                    width: 6,
                                  ),
                                  Text(
                                    (favoriteMeals[index].isGlutenFree)
                                        ? 'Gluten Free'
                                        : 'Has Gluten',
                                    style: Theme.of(context)
                                        .textTheme
                                        .caption
                                        .copyWith(color: Colors.black),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 7.0,
                              ),
                              Row(
                                children: <Widget>[
                                  Icon(
                                    Icons.brightness_1,
                                    size: 8.0,
                                    color: Colors.red[900],
                                  ),
                                  SizedBox(
                                    width: 6,
                                  ),
                                  Text(
                                    (favoriteMeals[index].isVegetarian)
                                        ? 'Vegetarian'
                                        : 'Non-Vegetarian',
                                    style: Theme.of(context)
                                        .textTheme
                                        .caption
                                        .copyWith(color: Colors.black),
                                  ),
                                ],
                              )
                            ],
                          ),
                        ))
                  ]),
                );
              },
              itemCount: favoriteMeals.length,
            ),
    );
  }
}
