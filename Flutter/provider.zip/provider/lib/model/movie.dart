import 'package:flutter/foundation.dart';

class MovieModel {
  String movieId;
  String movieName;
  bool isFavorite;

  MovieModel(
      {@required this.movieId,
      @required this.movieName,
      this.isFavorite = false});

  //This method gets called on icon tap but does not update the icon
  //as it does not extends ChangeNotifier and so cannot call notifyListeners().
  void toggleFavorite() {
    isFavorite = !isFavorite;
  }
}

class Movies {
  final List<MovieModel> _movies = [
    MovieModel(movieId: 'M1', movieName: 'The Godfather'),
    MovieModel(movieId: 'M2', movieName: 'The Notebook'),
  ];

  List<MovieModel> get movies {
    return _movies;
  }

  int get movieCount {
    return _movies.length;
  }

  MovieModel getByIndex(int index) {
    return _movies.elementAt(index);
  }

  void updateFavorite(MovieModel movie) {
    movie.toggleFavorite();
    print('Is Favorite ${movie.isFavorite}');
  }
}
