import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import './model/movie.dart';

class MovieTile extends StatelessWidget {
  final int movieIndex;

  MovieTile({this.movieIndex});

  @override
  Widget build(BuildContext context) {
    Movies movies = Provider.of<Movies>(context);
    MovieModel movie = movies.getByIndex(movieIndex);
    return ListTile(
      title: Text(
        movie.movieName,
        style: (movie.isFavorite)
            ? TextStyle(color: Colors.white)
            : TextStyle(color: Colors.white54),
      ),
      trailing: FavoriteIcon(movie: movie),
    );
  }
}

class FavoriteIcon extends StatelessWidget {
  final MovieModel movie;

  FavoriteIcon({this.movie});

  @override
  Widget build(BuildContext context) {
    Movies movies = Provider.of<Movies>(context);
    return IconButton(
        icon: (movie.isFavorite)
            ? Icon(
                Icons.favorite,
                color: Colors.red,
              )
            :
            // This does not update the icon as this app is using a basic Provider
            // Hence, it does not notify the listeners

            Icon(
                Icons.favorite_border,
                color: Colors.red,
              ),
        // This does not update the icon as this app is using a basic Provider
        // Hence, it does not notify the listeners
        onPressed: () {
          movies.updateFavorite(movie);
        });
  }
}
