import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import './model/movie.dart';

class MovieTile extends StatelessWidget {
  final int movieIndex;
  final Movies movies;

  MovieTile({this.movieIndex, this.movies});

  @override
  Widget build(BuildContext context) {
    MovieModel movie = movies.getByIndex(movieIndex);
    return ListTile(
      title: Text(
        movie.movieName,
        style: (movie.isFavorite)
            ? TextStyle(color: Colors.white)
            : TextStyle(color: Colors.white54),
      ),
      trailing: FavoriteIcon(movies: movies, movie: movie),
    );
  }
}

class FavoriteIcon extends StatelessWidget {
  final Movies movies;
  final MovieModel movie;
 
  FavoriteIcon({this.movies, this.movie});

  @override
  Widget build(BuildContext context) {
    return IconButton(
        icon: (movie.isFavorite)
            ? Icon(
                Icons.favorite,
                color: Colors.red,
              )
            :
            Icon(
                Icons.favorite_border,
                color: Colors.red,
              ),
        // This does not update the icon as this app is using a basic Provider
        // Hence, it does not notify the listeners
        onPressed: () {
          movies.updateFavorite(movie);
        });
  }
}
