import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

//import './simple_map.dart';
import './restaurant_businesses_map/screens/home_screen.dart';
import 'restaurant_businesses_map/providers/restaurants.dart';

void main() async {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<Restaurants>(
      create: (context) => Restaurants(),
      child: MaterialApp(
        title: 'Nearby Restaurants',
        theme: ThemeData(
          primaryColor: Color(0xFFFFCB202D),
          accentColor: Colors.white,
        ),
        home: HomeScreen(),
      ),
    );
  }
}
