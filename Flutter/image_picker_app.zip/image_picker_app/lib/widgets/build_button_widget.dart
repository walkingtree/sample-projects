import 'package:flutter/material.dart';

class BuildButtonWidget extends StatelessWidget {
  final String text;
  final Function onPressedHandler;

  BuildButtonWidget({@required this.text, @required this.onPressedHandler});

  @override
  Widget build(BuildContext context) {
    return RaisedButton.icon(
      icon: Icon(
        Icons.photo_library,
        color: Colors.cyan[900],
      ),
      label: Text(text),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(25.0),
      ),
      textColor: Colors.white,
      color: Theme.of(context).primaryColor,
      padding: EdgeInsets.all(10),
      onPressed: onPressedHandler,
    );
  }
}
