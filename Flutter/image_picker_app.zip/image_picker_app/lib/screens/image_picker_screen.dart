import 'package:flutter/material.dart';

import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart' as syspaths;

import 'dart:io';

import '../widgets/build_button_widget.dart';

class ImagePickerScreen extends StatefulWidget {
  @override
  _ImagePickerScreen createState() => _ImagePickerScreen();
}

class _ImagePickerScreen extends State<ImagePickerScreen> {
  File imageURI;
  File savedImage;

  //Create an instance of ImagePicker class of image_picker package.
  final ImagePicker imagePicker = ImagePicker();

  Future<void> getImageFromCamera() async {
    //Take an image with getImage() method of ImagePicker class.
    // It returns a file of PickedFile type.
    PickedFile pickedFile =
        await imagePicker.getImage(source: ImageSource.camera, maxWidth: 200);

    //Update the image variable for rebuild.
    setState(() {
      if (pickedFile == null) {
        return;
      }
      //Convert the PickedFile type to a File object
      imageURI = File(pickedFile.path);
    });
    //Save photo to app storage area
    await savePhoto(imageURI);
  }

  Future getImageFromGallery() async {
    //Returns an image file of PickedFile type
    PickedFile pickedFile =
        await imagePicker.getImage(source: ImageSource.gallery, maxWidth: 200);

    //Update the image variable for rebuild.
    setState(() {
      if (pickedFile == null) {
        return;
      }
      //Convert the PickedFile type to a File object
      imageURI = File(pickedFile.path);
    });
    //Save photo to app storage area
    await savePhoto(imageURI);
  }

  Future<void> savePhoto(imageURI) async {
    //Get the application storage directory path.
    final Directory appDir = await syspaths.getApplicationDocumentsDirectory();
    //Get the filename with extension from the full file name generated.
    final String fileName = path.basename(imageURI.path);
    //Save Image at the application storage path concatenated with the filename
    savedImage = await File(imageURI).copy('${appDir.path}/$fileName');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Take a Photo',
          style: TextStyle(color: Colors.white, fontSize: 24.0),
        ),
      ),
      body: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          CircleAvatar(
            radius: 80.0,
            backgroundImage: imageURI == null
                ? NetworkImage(
                    'https://movastore.sgp1.digitaloceanspaces.com/comnostalgiaselfiebeautycamera/appimage/nostalgia-camera-app-image-Z2T6K.png',
                  )
                : FileImage(imageURI),
          ),
          SizedBox(
            height: 20.0,
          ),
          BuildButtonWidget(
            text: 'Select Image From Gallery',
            onPressedHandler: getImageFromGallery,
          ),
          SizedBox(
            height: 5.0,
          ),
          BuildButtonWidget(
            text: 'Select Image From Camera',
            onPressedHandler: getImageFromCamera,
          ),
        ]),
      ),
    );
  }
}
