import 'package:flutter/material.dart';

import './screens/image_picker_screen.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Image Picker',
      theme: new ThemeData(
        primaryColor: const Color(0xFF02BB9F),
        accentColor: Colors.cyan[900],
        appBarTheme: AppBarTheme(
          iconTheme: IconThemeData(
            color: Colors.white,
          ),
        ),
      ),
      home: ImagePickerScreen(),
    );
  }
}
