import 'package:flutter/foundation.dart';

//Class to define structure of Movie
class MovieModel {
  String movieId;
  String movieName;
  bool isFavorite;

  MovieModel(
      {@required this.movieId,
      @required this.movieName,
      this.isFavorite = false});

  void toggleFavorite() {
    isFavorite = !isFavorite;
  }
}

// Class that holds data(state) and business logic
class Movies extends ChangeNotifier {
  // Stores MovieModel instances i.e. the movies.4
  // Each movie has movieId, movieName, isFavorite and toggleFavorite() method
  final List<MovieModel> _movies = [
    MovieModel(movieId: 'M1', movieName: 'The Godfather'),
    MovieModel(movieId: 'M2', movieName: 'The Notebook'),
  ];

  // Return the movies list
  List<MovieModel> get movies {
    return _movies;
  }

  //Return the total nmber of movies
  int get movieCount {
    return _movies.length;
  }

  // Returns movie at this index
  MovieModel getByIndex(int index) {
    return _movies.elementAt(index);
  }

  //This method gets called on icon tap to update the icon.
  //As it extends ChangeNotifier, you can call notifyListeners()
  //to notify all the listeners so that they can rebuild and update themselves.
  void updateFavorite(MovieModel movie) {
    movie.toggleFavorite();
    notifyListeners();
  }
}
