import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import './model/movie.dart';

// This widget listens to updates, rebuilds the whole subtree.
class MovieTile extends StatelessWidget {
  final int movieIndex;
  final Movies movies;

  MovieTile({this.movieIndex, this.movies});

  @override
  Widget build(BuildContext context) {
    //Uses the movies object to access its method
    MovieModel movie = movies.getByIndex(movieIndex);
    return ListTile(
      title: Text(
        movie.movieName,
        style: (movie.isFavorite)
            ? TextStyle(color: Colors.white)
            : TextStyle(color: Colors.white54),
      ),
      trailing: FavoriteIcon(movie: movie, movies: movies),
    );
  }
}

class FavoriteIcon extends StatelessWidget {
  final MovieModel movie;
  final Movies movies;

  FavoriteIcon({this.movie, this.movies});

  @override
  Widget build(BuildContext context) {
    return IconButton(
        icon: (movie.isFavorite)
            ? Icon(
                Icons.favorite,
                color: Colors.red,
              )
            : Icon(
                Icons.favorite_border,
                color: Colors.red,
              ),
        onPressed: () {
          // This toggles  the isFavorite status and notifies all the listeners
          movies.updateFavorite(movie);
        });
  }
}
