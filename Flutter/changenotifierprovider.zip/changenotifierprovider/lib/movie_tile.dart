import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import './model/movie.dart';

// This widget listens to updates, rebuilds the whole subtree.
class MovieTile extends StatelessWidget {
  final int movieIndex;

  MovieTile({this.movieIndex});

  @override
  Widget build(BuildContext context) {
    //Exposes Movies object
    Movies movies = Provider.of<Movies>(context);
    //Uses the movies object to access its method
    MovieModel movie = movies.getByIndex(movieIndex);
    return ListTile(
      title: Text(
        movie.movieName,
        style: (movie.isFavorite)
            ? TextStyle(color: Colors.white)
            : TextStyle(color: Colors.white54),
      ),
      trailing: FavoriteIcon(movie: movie),
    );
  }
}

class FavoriteIcon extends StatelessWidget {
  final MovieModel movie;

  FavoriteIcon({this.movie});

  @override
  Widget build(BuildContext context) {
    Movies movies = Provider.of<Movies>(context);
    return IconButton(
        icon: (movie.isFavorite)
            ? Icon(
                Icons.favorite,
                color: Colors.red,
              )
            : Icon(
                Icons.favorite_border,
                color: Colors.red,
              ),
        onPressed: () {
          // This toggles  the isFavorite status and notifies all the listeners
          movies.updateFavorite(movie);
        });
  }
}
