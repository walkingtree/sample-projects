import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import './model/movie.dart';
import './movie_tile.dart';

// This widget listens to updates, rebuilds the whole subtree.
class MovieListView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    //Exposes Movies object
    Movies movies = Provider.of<Movies>(context);

    return ListView.builder(
        //Uses the movies object to access its property
        itemCount: movies.movieCount,
        itemBuilder: (BuildContext context, int index) {
          return MovieTile(
            movieIndex: index,
            movies: movies,
          );
    });
  }
}

