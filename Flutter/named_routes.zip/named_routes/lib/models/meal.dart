import 'package:flutter/material.dart';

// Create a class that contains a customizable meal with id, category, title,
// imageUrl, ingredients, isGlutenFree, isVegetarian
class Meal {
  final String id;
  final String category;
  final String title;
  final String imageUrl;
  final List<String> ingredients;
  final bool isGlutenFree;
  final bool isVegetarian;
  
  const Meal({
    @required this.id,
    @required this.category,
    @required this.title,
    @required this.imageUrl,
    @required this.ingredients,
    @required this.isGlutenFree,
    @required this.isVegetarian,
  });
}

