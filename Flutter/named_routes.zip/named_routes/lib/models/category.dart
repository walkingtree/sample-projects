import 'package:flutter/material.dart';

// Create a class that contains a customizable category with id and title.
class Category {
  final String id;
  final String title;

  const Category({
    @required this.id,
    @required this.title
  });
}


