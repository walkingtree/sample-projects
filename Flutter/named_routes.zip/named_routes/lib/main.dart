import 'package:flutter/material.dart';
import './screens/named_routes/myapp.dart';

void main() => runApp(MyApp());

