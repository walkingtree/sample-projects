import './models/category.dart';
import './models/meal.dart';

const CATEGORIES = const [
  Category(
    id: 'c1',
    title: 'Indian',
  ),
  Category(
    id: 'c2',
    title: 'Italian',
  )
];

const MEALS = const [
  Meal(
    id: 'm1',
    category: 'c1',
    title: 'Quick Paneer',
    imageUrl:
        'http://mypullzone.9vexd6dl53at.maxcdn-edge.com/wp-content/uploads/2016/08/kadai-paneer-gravy-recipe-step-by-step-instructions.jpg',
    ingredients: [
      '4 Tomatoes',
      '2 Tablespoon Oil',
      '2 Onions',
      '2 Tablespoon Ginger-Garlic Paste',
      '250g Paneer',
      'Spices',
      '4 Tablespoon Cream'
    ],
    isGlutenFree: true,
    isVegetarian: true,
  ),
  Meal(
    id: 'm2',
    category: 'c2',
    title: 'Spaghetti',
    imageUrl:
        'https://www.bbcgoodfood.com/sites/default/files/styles/push_item/public/recipe/recipe-image/2018/05/440-400-spaghetti-puttanesca-with-red-beans-spinach.jpg?itok=hGSAgdtS',
    ingredients: [
      '4 Tomatoes',
      '1 Tablespoon of Olive Oil',
      '1 Onion',
      '5 Olives',
      '5 Jalepenos',
      '250g Spaghetti',
      'Spices',
      'Cheese (optional)'
    ],
    isGlutenFree: false,
    isVegetarian: true,
  ),
  Meal(
    id: 'm3',
    category: 'c2',
    title: 'Penne in Red Sauce',
    imageUrl:
        'http://www.thewholegang.org/wp-content/uploads/2011/10/Chicken-Penne1-300x201.jpg',
    ingredients: [
      '1 Cup Tomato Puree',
      '1 Tablespoon of Olive Oil',
      '1 Onion',
      '1 Red and 1 Yellow Bell Pepper',
      '50g Mushrooms',
      '50g Broccoli',
      '400g Penne',
      'Spices',
      'Cheese (optional)'
    ],
    isGlutenFree: false,
    isVegetarian: true,
  ),
  Meal(
    id: 'm4',
    category: 'c1',
    title: 'Lachha Paratha',
    imageUrl:
        'https://tse4.mm.bing.net/th?id=OIP.SH_0FkZd8fZaSThKvmF3hQAAAA&pid=Api&P=0&w=220&h=166',
    ingredients: ['4 Tablespoon Oil', 'Spices', 'All purpose flour'],
    isGlutenFree: false,
    isVegetarian: true,
  ),
];
