import 'package:flutter/material.dart';

class MainDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    
    return Drawer(
      elevation: 2.0,
      child: Container(
        child: Column(
          children: <Widget>[
            Container(
              padding: EdgeInsets.only(
                left: 20.0,
                top: 40.0,
              ),
              width: double.infinity,
              height: 100.0,
              color: Theme.of(context).primaryColor,
              child: Text(
                'Meals App',
                style: Theme.of(context).textTheme.headline6,
              ),
            ),
            SizedBox(height: 20.0),
            InkWell(
              onTap: () {
                Navigator.pushNamed(
                  context,
                  '/',
                );
              },
              child: ListTile(
                leading: Icon(Icons.home,
                    color: Theme.of(context).primaryColor, size: 30.0),
                title: Text(
                  'Categories',
                  style: Theme.of(context)
                      .textTheme
                      .bodyText2
                      .copyWith(color: Colors.black),
                ),
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.pushNamed(
                  context,
                  '/favoriteMealsScreen',
                );
              },
              child: ListTile(
                leading: Icon(
                  Icons.favorite,
                  color: Theme.of(context).primaryColor,
                  size: 30.0,
                ),
                title: Text(
                  'Favorites',
                  style: Theme.of(context)
                      .textTheme
                      .bodyText2
                      .copyWith(color: Colors.black),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
