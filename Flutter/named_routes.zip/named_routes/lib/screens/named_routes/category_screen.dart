import 'package:flutter/material.dart';

import '../../widgets/main_drawer.dart';
import '../../models/category.dart';
import '../../data.dart';

class CategoryScreen extends StatelessWidget {
  // Traverses through the 'CATEGORIES' list and creates a new list 'categories' with each 'Category' object.
  final List<Category> categories = CATEGORIES.map((catData) {
    return catData;
  }).toList();

  @override
  Widget build(BuildContext context) {
    // Called when any category is tapped.
    // pushNamed takes 3 arguments - context, route name and optional arguments.
    onCategoryTapHandler(index) {
      Navigator.pushNamed(
        context,
        '/mealsScreen',
        arguments: <String, String>{
          'catId': categories[index].id,
        },
      );
    }

    return Scaffold(
      // Has the back button
      appBar: AppBar(
        title: Text('Categories'),
      ),

      // Creates a side drawer
      drawer: MainDrawer(),

      body: GridView.builder(
        padding: const EdgeInsets.all(25),
        itemCount: categories.length,
        itemBuilder: (context, index) {
          return InkWell(
            child: Container(
              child: Center(
                child: Text(
                  categories[index].title,
                  style: Theme.of(context).textTheme.headline6,
                ),
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: Color(0xFF1D1E33),
              ),
            ),

            // Tap on any category takes to to the meal screen
            onTap: () {
              onCategoryTapHandler(index);
            },
          );
        },
        gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 200,
          childAspectRatio: 3 / 2,
          crossAxisSpacing: 20,
          mainAxisSpacing: 20,
        ),
      ),
    );
  }
}
