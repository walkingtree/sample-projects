import 'package:flutter/material.dart';
import '../../models/meal.dart';
import '../../data.dart';

class MealDetailScreen extends StatefulWidget {
  @override
  _MealDetailScreenState createState() => _MealDetailScreenState();
}

class _MealDetailScreenState extends State<MealDetailScreen> {
  bool isFavorite = false;

  @override
  Widget build(BuildContext context) {
    // Extract the arguments from the current ModalRoute settings and cast
    // them as Map - same as passed with pushNamed().
    final Map<String, String> args = ModalRoute.of(context).settings.arguments;

    // Traverses through the 'MEALS' list and returns a Meal object that matches the mealId.
    // [] brackets are used to access property of a Map object.
    final Meal mealDetail = MEALS.firstWhere((meal) {
      return (meal.id == args['mealId']);
    });

    return Scaffold(
      //Optionally, user can go back to Screen2 via this button
      floatingActionButton: FloatingActionButton(
          backgroundColor: Colors.red[900],
          child: Icon(
            Icons.arrow_back,
            size: 35.0,
          ),
          onPressed: () {}),

      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Stack(
              alignment: Alignment.bottomRight,
              children: [
                Container(
                  height: 300,
                  width: double.infinity,
                  child: Image.network(
                    mealDetail.imageUrl,
                    fit: BoxFit.cover,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 40.0),
                  child: Container(
                      color: Colors.black38,
                      child: Text(
                        mealDetail.title,
                        style: Theme.of(context).textTheme.bodyText2,
                      )),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Container(
                  margin: EdgeInsets.symmetric(vertical: 10),
                  child: Text(
                    'Ingredients',
                    style: Theme.of(context).textTheme.bodyText1,
                  ),
                ),
                SizedBox(width: 14.0),
                GestureDetector(
                  child: Icon(
                    (isFavorite) ? Icons.favorite : Icons.favorite_border,
                    color: Colors.red[900],
                    size: 35.0,
                  ),
                  onTap: () {
                    if (isFavorite == false) {
                      setState(() {
                        isFavorite = true;
                      });
                    } else {
                      setState(() {
                        isFavorite = false;
                      });
                    }
                  },
                ),
              ],
            ),
            Container(
              height: 200,
              child: ListView.builder(
                itemCount: mealDetail.ingredients.length,
                itemBuilder: (ctx, index) => Card(
                  color: Theme.of(context).primaryColor,
                  child: Padding(
                      padding: EdgeInsets.symmetric(
                        vertical: 5,
                        horizontal: 10,
                      ),
                      child: Text(mealDetail.ingredients[index])),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
