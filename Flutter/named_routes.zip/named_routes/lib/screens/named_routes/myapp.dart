import 'package:flutter/material.dart';
import '../../util/meal_theme.dart';
import './category_screen.dart';
import './meals_screen.dart';
import './meal_detail_screen.dart';
import './favorite_meals_screen.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: 'Meals App', theme: MealTheme.buildMealTheme(),

        //Declares all routes needed in the app.
        //Here, the MaterialApp is created with a Map<String, WidgetBuilder>
        // which maps from a route's name to a builder function that will create it.
        routes: <String, WidgetBuilder>{
          '/': (BuildContext context) => CategoryScreen(),
          '/mealsScreen': (BuildContext context) => MealsScreen(),
          '/mealDetailScreen': (BuildContext context) => MealDetailScreen(),
          '/favoriteMealsScreen': (BuildContext context) =>
            FavoriteMealsScreen(),
        });
  }
}
