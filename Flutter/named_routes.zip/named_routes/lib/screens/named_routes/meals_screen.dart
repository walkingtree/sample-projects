import 'package:flutter/material.dart';

import '../../models/meal.dart';
import '../../data.dart';

class MealsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Extract the arguments from the current ModalRoute settings and cast
    // them as Map - same as passed with pushNamed().
    final Map<String, String> args = ModalRoute.of(context).settings.arguments;

    // Traverses through the 'MEALS' list and creates a new list 'meals' with each 'Meal' object.
    // [] brackets are used to access property of a Map object.
    final List<Meal> meals = MEALS.where((mealData) {
      return mealData.category == args['catId'];
    }).toList();

    // Called when any meal is tapped.
    // pushNamed takes 3 arguments - context, route name and optional arguments.
    onMealTapHandler(index) {
      Navigator.pushNamed(
        context,
        '/mealDetailScreen',
        arguments: <String, String>{
          'mealId': meals[index].id,
        },
      );
    }

    return Scaffold(
      //Adds back button
      appBar: AppBar(
        title: Text('Meals'),
      ),

      body: ListView.separated(
        itemCount: meals.length,
        itemBuilder: (context, index) {
          return InkWell(
            // Tap on any meal takes to the detail screen
            onTap: () {
              onMealTapHandler(index);
            },
            child: Stack(
              alignment: Alignment.centerLeft,
              children: <Widget>[
                Container(
                  margin: EdgeInsets.only(left: 90),
                  width: double.infinity,
                  height: 100.0,
                  child: Card(
                    color: Color(0xFF1D1E33),
                    child: Padding(
                      padding: const EdgeInsets.only(
                          top: 8.0, bottom: 8.0, left: 34.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          Text(
                            meals[index].title,
                            style: Theme.of(context).textTheme.bodyText2,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Row(
                                children: [
                                  Icon(
                                    Icons.brightness_1,
                                    size: 8.0,
                                    color: Colors.amber[600],
                                  ),
                                  SizedBox(width: 5.0),
                                  Text(
                                    (meals[index].isGlutenFree)
                                        ? 'Gluten Free'
                                        : 'Has Gluten',
                                    style: Theme.of(context).textTheme.caption,
                                  ),
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Icon(
                                    Icons.brightness_1,
                                    size: 8.0,
                                    color: Colors.amber[600],
                                  ),
                                  SizedBox(width: 5.0),
                                  Text(
                                    (meals[index].isVegetarian)
                                        ? 'Vegetarian'
                                        : 'Non-Vegetarian',
                                    style: Theme.of(context).textTheme.caption,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: CircleAvatar(
                    backgroundColor: Colors.amber[600],
                    backgroundImage: NetworkImage(
                      meals[index].imageUrl,
                    ),
                    radius: 50.0,
                  ),
                ),
              ],
            ),
          );
        },
        separatorBuilder: (context, int) {
          return SizedBox(
            height: 8.0,
          );
        },
      ),
    );
  }
}
