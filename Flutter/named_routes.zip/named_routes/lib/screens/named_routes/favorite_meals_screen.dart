import 'package:flutter/material.dart';
import '../../widgets/main_drawer.dart';

class FavoriteMealsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Favorite Meals'),
        ),
        drawer: MainDrawer(),
        body: Center(
          child: Text(
            'You have no favorites!',
            style: Theme.of(context).textTheme.bodyText1,
          ),
        ));
  }
}
