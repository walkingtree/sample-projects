import 'package:flutter/material.dart';

class MealTheme {
  MealTheme();
  static ThemeData buildMealTheme() {
    final ThemeData base = ThemeData.light();
    return base.copyWith(
      primaryColor: Colors.amber[600],
      scaffoldBackgroundColor: Color(0xFF090C22),
      appBarTheme: AppBarTheme(
        textTheme: TextTheme(
          headline6: TextStyle(
            fontSize: 26.0,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      textTheme: TextTheme(
        bodyText1: TextStyle(fontSize: 30.0, fontWeight: FontWeight.bold),
        headline6: TextStyle(
          fontSize: 26.0,
          fontWeight: FontWeight.bold,
        ),
        bodyText2: TextStyle(fontSize: 22.0, fontWeight: FontWeight.bold),
        caption: TextStyle(fontSize: 14.0, fontWeight: FontWeight.normal )
      ),
    );
  }
}
