import 'package:Flutter/material.dart';
import 'package:provider/provider.dart';

import 'util/movie_theme.dart';
import './screens/movie_listview.dart';
import './screens/main_drawer.dart';
import './models/movie.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<Movies>(
      create: (context) => Movies(),
      child: MaterialApp(
        title: 'Flutter Demo',
        theme: movieTheme,
        home: 'MyHomePage',
        routes: {
          'FavoriteMovies.routeName': (context) => FavoriteMovies(),
        }
      ),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Movies',
        ),
      ),
      drawer: MainDrawer(),
      body: MovieListView(),
    );
  }
}
