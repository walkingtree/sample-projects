import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import './model/movie.dart';

// This widget consumes data and listens to updates also.
// Hence rebuilds the whole subtree.
class MovieTile extends StatelessWidget {
  final int movieIndex;

  MovieTile({this.movieIndex});

  @override
  Widget build(BuildContext context) {
    // Consumes data of type Movies
    return Consumer<Movies>(
      builder: (context, movies, child) {
        MovieModel movie = movies.movies[movieIndex];
        return ListTile(
          title: Text(
            movie.movieName,
            style: (movie.isFavorite)
                ? TextStyle(color: Colors.white)
                : TextStyle(color: Colors.white54),
          ),
          trailing: FavoriteIcon(movie: movie),
        );
      },
    );
  }
}

class FavoriteIcon extends StatelessWidget {
  final MovieModel movie;

  FavoriteIcon({this.movie});

  @override
  Widget build(BuildContext context) {
    return IconButton(
      //Accesses data and listens. Hence rebuilds and updates.
      icon: (movie.isFavorite)
          ? Icon(
              Icons.favorite,
              color: Colors.red,
            )
          : Icon(
              Icons.favorite_border,
              color: Colors.red,
            ),
      onPressed: () {
        // Accesses method but does not listen to updates.
        // Hence IconButton does not rebuild.
        Provider.of<Movies>(context, listen: false).updateFavorite(movie);
      },
    );
  }
}
