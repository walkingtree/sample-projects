import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../widgets/users_list.dart';
import 'dart:async';
import '../services/api_service.dart';

class HomeScreen extends StatefulWidget {
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final baseUrl = 'https://jsonplaceholder.typicode.com';

  Future<dynamic> futureUsers;

  //TODO 2: Make a network call to feth data inside the initState() method.

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Users',
          style: TextStyle(
            color: Colors.white,
            fontSize: 28.0,
          ),
        ),
      ),
      // TODO 3: Add the Scaffold body.
      // TODO 4. Show the loading mask.
    );
  }
}
