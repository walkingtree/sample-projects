import 'package:flutter/material.dart';
import '../models/user_model.dart';

class UserScreen extends StatelessWidget {
  final UserModel user;

  UserScreen(this.user);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'User',
        ),
      ),
      body: Container(
        alignment: Alignment.center,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
             "Name: ${user.name}",
              style: Theme.of(context).textTheme.bodyText2,
            ),
            Text(
             "City: ${user.address['city']}",
              style: Theme.of(context).textTheme.bodyText2,
            ),
            Text(
              "Company:  ${user.company['name']}",
              style: Theme.of(context).textTheme.bodyText2,
            ),
          ],
        ),
      ),
    );
  }
}
