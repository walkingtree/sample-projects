import 'package:flutter/material.dart';
import './ui/bmi_app.dart';

void main() => runApp(
      new MaterialApp(
        home: Scaffold(
          resizeToAvoidBottomInset: false,
          appBar: AppBar(
            title: Text("BMI"),
          ),
          body: BmiApp(),
        ),
      ),
    );
