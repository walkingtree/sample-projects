import 'package:flutter/material.dart';

class BmiInputs extends StatelessWidget {
  final double parameterValue;
  final String parameterName;
  final Function onChangedHandler;
  final double min;
  final double max;

  const BmiInputs(
      {@required this.min,
      @required this.max,
      @required this.parameterValue,
      @required this.parameterName,
      @required this.onChangedHandler});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 5.0),
      child: Column(
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text(
                "$parameterName",
              ), //TODO: theme this!
              Text("${parameterValue.toStringAsFixed(2)}")
            ],
          ),

          //Slider
          Slider(
              min: min,
              max: max,
              activeColor: Colors.blueGrey, //TODO: Theme this!
              inactiveColor: Colors.grey, //TODO: Theme this!
              value: parameterValue,
              onChanged: onChangedHandler),
        ],
      ),
    );
  }
}
