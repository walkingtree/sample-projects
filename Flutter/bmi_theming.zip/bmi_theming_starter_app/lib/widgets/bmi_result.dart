import 'package:flutter/material.dart';

class BmiResult extends StatelessWidget {
  final String name;
  final String bmi;
  final String result;
  final String interpretation;

  const BmiResult({
    this.name,
    this.bmi,
    this.result,
    this.interpretation,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 130,
      child: Card(
        elevation: 5,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Text(
              (bmi != '') ? "BMI: $bmi" : "BMI",
              //TODO Theme this style
            ),
            SizedBox(height: 9),
            Text(
              (name != '' && result != '') ? "$name, you are $result" : '',
              //TODO Theme this style
            ),
            SizedBox(height: 5),
            Text(
              (interpretation != '') ? '$interpretation' : '',
              textAlign: TextAlign.center,
              //TODO Theme this style
            )
          ],
        ),
      ),
    );
  }
}
