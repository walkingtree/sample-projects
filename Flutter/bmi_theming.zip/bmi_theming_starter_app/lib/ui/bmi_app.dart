import 'package:flutter/material.dart';
import '../widgets/bmi_inputs.dart';
import '../widgets/bmi_result.dart';
import '../widgets/age_input_button.dart';
import '../calculate_bmi.dart';

class BmiApp extends StatefulWidget {
  @override
  _BmiAppState createState() => _BmiAppState();
}

class _BmiAppState extends State<BmiApp> {
  double _height = 120;
  double _weight = 70;
  String _name = '';
  int _age = 26;
  String _bmi = '';
  String _result = '';
  String _interpretation = '';

  //Set height input by the slider
  void _heightChangedHandler(double newValue) {
    setState(() {
      _height = newValue;
    });
  }

  // Set weight input by the slider
  void _weightChangedHandler(double newValue) {
    setState(() {
      _weight = newValue;
    });
  }

  // Set age when plus icon is tapped
  void _incrementAgeHandler() {
    setState(() {
      _age++;
    });
  }

  // Set age when minus icon is tapped
  void _decrementAgeHandler() {
    setState(() {
      _age--;
    });
  }

  // To calculate BMI when 'Caculate BMI' button is clicked
  void calculateBMIHandler() {
    //To create instance of CalculatBMI class which has the application logic
    CalculatBMI calc = CalculatBMI(height: _height, weight: _weight);
    setState(() {
      _bmi = calc.getBMI();
      _result = calc.getResult();
      _interpretation = calc.getInterpretation();
    });
  }

  // Builder method to render Textfield widget for name
  Widget _builderName() {
    return Container(
      margin: EdgeInsets.only(top: 8.0),
      //decoration: ..TODO Theme this Container
      child: TextField(
        keyboardType: TextInputType.text,
        decoration: InputDecoration(
          hintText: "Name",
        ),
        onChanged: (String value) {
          setState(() {
            try {
              _name = value;
            } catch (exception) {
              _name = '';
            }
          });
        },
      ), //TODO: theme this Textfield!
    );
  }

  // Builder method to render Age buttons
  Widget _builderAge() {
    return Container(
      margin: EdgeInsets.only(top: 5.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Text("Age(years)"), //...TODO: Theme this!
          Row(
            children: <Widget>[
              //Reusable age button widget
              AgeInputButton(
                icon: Icons.remove,
                onTapHandler: _decrementAgeHandler,
                //TODO Theme the icon
              ),
              Text("$_age"
                  //TODO: Theme the style
                  ),
              //Reusable age button widget
              AgeInputButton(
                icon: Icons.add,
                onTapHandler: _incrementAgeHandler,
                //TODO Theme the icon
              ),
            ],
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        alignment: Alignment.center,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            //Widget to render the calculated BMI result
            BmiResult(
              name: _name,
              bmi: _bmi,
              result: _result,
              interpretation: _interpretation,
            ),
            // Builder method to render Name Textfield
            _builderName(),
            // Builder method to render Age buttons
            _builderAge(),
            //Widget to render height slider
            BmiInputs(
              min: 60,
              max: 220,
              parameterValue: _height,
              parameterName: 'Height(cm)',
              onChangedHandler: _heightChangedHandler,
            ),
            //Widget to render weight slider
            BmiInputs(
              min: 20,
              max: 120,
              parameterValue: _weight,
              parameterName: 'Weight(kg)',
              onChangedHandler: _weightChangedHandler,
            ),
            //Button to calculate BMI
            Padding(
              padding: const EdgeInsets.only(top: 16.0),
              child: RaisedButton(
                //TODO  Theme this button
                child: Text(
                  'Calculate BMI',
                  //TODO Theme this style
                ),
                onPressed: calculateBMIHandler,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
