import 'package:flutter/foundation.dart';
import 'package:geocoder/geocoder.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../services/api_service.dart';
import '../services/location_service.dart';

import '../model/restaurant_model.dart';

class Restaurants extends ChangeNotifier {
  RestaurantModel _restaurantData; // fetched nearby restaurant details
  List<Marker> _markerList = <Marker>[]; // To store markers for all restaurants
  double _cityLat;
  double _cityLong;

  // Get the geographicla coordinates at this city
  Future<void> getAddress(query) async {
    Address address = await LocationService().getLocation(query);
    if (address != null) {
      _cityLat = address.coordinates.latitude;
      _cityLong = address.coordinates.longitude;
    } else {
      throw Exception('Geographical Coordinates not found!');
    }
  }

  // Create markerList for all the restaurant addresses
  void createMarkers() {
    _markerList.clear();
    _restaurantData.nearbyRestaurants.forEach((nearByRest) => {
          _markerList.add(Marker(
              markerId: MarkerId(nearByRest.restaurant.id),
              infoWindow: InfoWindow(
                title: "${nearByRest.restaurant.name}  (Rating: ${nearByRest.restaurant.userRating.aggregateRating})",
                snippet: "Cuisine: ${nearByRest.restaurant.cuisines}",
              ),                    
              icon: BitmapDescriptor.defaultMarkerWithHue(
                BitmapDescriptor.hueRed,
              ),
              position: LatLng(
                double.parse(nearByRest.restaurant.location.latitude),
                double.parse(nearByRest.restaurant.location.longitude),
              ),
              onTap: () {}))
        });
  }

  // Get all the nearby restaurant details
  Future<void> getRestaurantData(query) async {
    await getAddress(query);
    _restaurantData = await ApiService().getAllRestaurants(_cityLat, _cityLong);
    if (_restaurantData != null) {
      createMarkers();
      notifyListeners();
    } else {
      throw Exception('Restaurants not found!');
    }
  }

  // Get marker list
  List<Marker> get markers {
    return _markerList;
  }

  // Get city latitude
  double get cityLatitude {
    return _cityLat;
  }

  //Get city Longitude
  double get cityLongitude {
    return _cityLong;
  }
}
