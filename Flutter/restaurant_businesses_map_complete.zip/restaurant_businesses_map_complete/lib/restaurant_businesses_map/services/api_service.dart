import 'dart:convert';
import 'package:maps/restaurant_businesses_map/model/restaurant_model.dart';
import 'package:http/http.dart' as http;

class ApiService {
  static const apiKey = "149529abf97ed17c00a3cfcf2d53016c";

  Future<RestaurantModel> getAllRestaurants(latitude, longitude) async {
    var apiUrl =
        'https://developers.zomato.com/api/v2.1/geocode?lat=$latitude&lon=$longitude&apikey=$apiKey';

    final http.Response response = await http.get(Uri.encodeFull(apiUrl));

    if (response.statusCode == 200) {
      print("Restaurant data: ${response.body}");
      return RestaurantModel.fromJson(json.decode(response.body));
    } else {
      throw Exception("Error getting Restaurants");
    }
  }
}
