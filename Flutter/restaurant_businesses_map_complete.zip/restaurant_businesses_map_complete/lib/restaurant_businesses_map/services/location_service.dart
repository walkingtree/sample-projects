import 'package:geocoder/geocoder.dart' as geo;

class LocationService {
  Future<geo.Address> getLocation(String query) async {
    var addresses = await geo.Geocoder.local.findAddressesFromQuery(query);
    if (addresses != null) {
      geo.Address address = addresses.first;
      return address;
    } else {
      throw Exception('Geographical Coordinates not found!');
    }
  }
}
