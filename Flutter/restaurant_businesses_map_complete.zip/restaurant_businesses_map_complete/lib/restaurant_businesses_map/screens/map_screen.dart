import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'dart:async';
import 'package:provider/provider.dart';
import '../providers/restaurants.dart';

class MapScreen extends StatefulWidget {
  final String query;
  MapScreen(this.query);
  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  Completer<GoogleMapController> _controller = Completer();
  double _zoomVal = 12.0;
  List<Marker> _markerList = [];
  double _cityLatitude;
  double _cityLongitude;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          _buildZoomMinus(),
          _buildZoomPlus(),
        ],
      ),
      body: _buildGoogleMap(context),
    );
  }

  //Create the zoom plus widget
  Widget _buildZoomPlus() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: IconButton(
          icon: Icon(
            FontAwesomeIcons.searchPlus,
            color: Colors.white,
          ),
          onPressed: () {
            _zoomVal++;
            _plus();
          }),
    );
  }

  //Create the zoom minus widget
  Widget _buildZoomMinus() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: IconButton(
        onPressed: () {
          _zoomVal--;
          _minus();
        },
        icon: Icon(
          FontAwesomeIcons.searchMinus,
          color: Colors.white,
        ),
      ),
    );
  }

  // Consume data and Create the Google Map widget
  Widget _buildGoogleMap(BuildContext context) {
    return Consumer<Restaurants>(builder: (context, nearByRest, child) {
      _markerList = nearByRest.markers;
      _cityLatitude = nearByRest.cityLatitude;
      _cityLongitude = nearByRest.cityLongitude;
      return Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: GoogleMap(
          mapType: MapType.normal,
          //mapToolbarEnabled: false,
          zoomControlsEnabled: false,
          onMapCreated: (GoogleMapController controller) {
            _controller.complete(controller);
          },
          initialCameraPosition: CameraPosition(
            target: LatLng(_cityLatitude, _cityLongitude),
            zoom: _zoomVal, //City as the initial position
          ),
          markers: Set<Marker>.of(_markerList), // (_markerList != null)
        ), //Set markers for all the restaurant locations
      );
    });
  }

  // Handle zoom minus.
  //Focus the initial camera at the city address and reduce zoom level from there.
  Future<void> _minus() async {
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(
          target: LatLng(_cityLatitude, _cityLongitude),
          zoom: _zoomVal,
        ),
      ),
    );
  }

  // Handle zoom plus.
  // Focus the initial camera at the city address and increase zoom from there.
  Future<void> _plus() async {
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(
          target: LatLng(_cityLatitude, _cityLongitude),
          zoom: _zoomVal,
        ),
      ),
    );
  }
}
