import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/restaurants.dart';
import '../utilities/constants.dart';
import './map_screen.dart';

class HomeScreen extends StatelessWidget {
  void textSubmitHandler(context, query) async {
    Restaurants restaurantProvider =
        Provider.of<Restaurants>(context, listen: false);
    await restaurantProvider.getRestaurantData(query);
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) {
        return MapScreen(query);
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFFFFCB202D),
        title: Text(
          'Restaurants',
          style: kAppBarTitleStyle,
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 90.0,
                backgroundColor: Colors.red[50],
                child: CircleAvatar(
                  radius: 60.0,
                  backgroundColor: Colors.red[900],
                  backgroundImage: AssetImage('assets/images/restaurant.jpg'),
                ),
              ),
              SizedBox(height: 12.0),
              Text('Get Nearby Restaurants', style: kBodyTextStyle),
              Padding(
                padding: EdgeInsets.only(
                  top: 20.0,
                  left: 20.0,
                  right: 20.0,
                  bottom: MediaQuery.of(context).viewInsets.bottom,
                ),
                child: TextField(
                    style: kTextFieldTextStyle,
                    keyboardType: TextInputType.text,
                    showCursor: true,
                    cursorColor: Colors.white,
                    autofocus: true,
                    textAlign: TextAlign.center,
                    decoration: kTextFieldInputDecoration,
                    onSubmitted: (query) {
                      textSubmitHandler(context, query);
                    }),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
