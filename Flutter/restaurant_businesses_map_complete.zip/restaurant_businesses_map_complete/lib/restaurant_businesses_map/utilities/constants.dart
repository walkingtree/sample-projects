import 'package:flutter/material.dart';

const kAppBarTitleStyle = TextStyle(
  fontFamily: 'SourceSansPro',
  fontSize: 22.0,
);

const kBodyTextStyle = TextStyle(
  fontFamily: 'SourceSansPro',
  fontSize: 16.0,
  fontWeight: FontWeight.bold,
);

const kTextFieldTextStyle = TextStyle(
  color: Colors.white,
  fontFamily: 'SourceSansPro',
  fontSize: 16.0,
);

const kTextFieldInputDecoration = InputDecoration(
  contentPadding: EdgeInsets.all(0.0),
  filled: true,
  fillColor: Color(0xFFFFCB202D),
  hintText: 'Enter City',
  hintStyle: TextStyle(
    color: Colors.white,
    fontFamily: 'SourceSansPro',
  ),
  border: OutlineInputBorder(
    borderRadius: BorderRadius.all(
      Radius.circular(10.0),
    ),
    borderSide: BorderSide.none,
  ),
);
