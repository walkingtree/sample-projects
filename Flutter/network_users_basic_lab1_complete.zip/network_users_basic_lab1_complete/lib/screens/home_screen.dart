import 'package:flutter/material.dart';
import './user_screen.dart';
import '../models/user_model.dart';
import '../services/api_service.dart';
// import '../screens/users_screen.dart';

class HomeScreen extends StatefulWidget {
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final String baseUrl = 'https://jsonplaceholder.typicode.com';

  Future getUser() async {
    final String url = '$baseUrl/users/1';

    //Make network by calling the service method
    var parsedJson = await ApiService(url).fetchData();

    // Create a user
    UserModel user = UserModel.fromJson(parsedJson);

    //Navigate to next page to display the User name
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) {
          // Return UsersScreen instance.
          return UserScreen(user);
        },
      ),
    );
  }

  //Without a dedicated service class
  /*Future getUser() async {
    //Make network by calling get() method  to fetch data
    final http.Response response =
        await http.get('https://jsonplaceholder.typicode.com/users/1');

    //Check if network call is successful.
    if (response.statusCode == 200) {
       // Convert and print response body String to JSON.
      final parsedJson = json.decode(response.body);
      print('Fetched Data: $parsedJson');

      //json.decode() returns a Map<String, dynamic>
     // print(
         // "Name: ${parsedJson['name']} City: ${parsedJson['address']['city']} Company: ${parsedJson['company']['name']}");

      // Create a UserModel object.
      UserModel user = UserModel.fromJson(parsedJson);

      //Navigate to next page to display the User name
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) {
            //  return UsersScreen instance.
            return UserScreen(user);
          },
        ),
      );
    }
    // If request failed
    else {
      print('Http call was not successful.');
    }
  }*/

  Future getUsers() async {}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Networking',
          style: TextStyle(
            color: Colors.white,
            fontSize: 28.0,
          ),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            RaisedButton(
              child: Text(
                'Get User',
                style: Theme.of(context).textTheme.bodyText1,
              ),
              onPressed: getUser,
            ),
            SizedBox(
              height: 20.0,
            ),
            RaisedButton(
              child: Text(
                'Get Users',
                style: Theme.of(context).textTheme.bodyText1,
              ),
              onPressed: getUsers,
            ),
          ],
        ),
      ),
    );
  }
}
