const outputElement = document.getElementById('output');
const eles = document.getElementsByTagName('div');

function output(msg) {
  outputElement.innerText += (`${msg}\n`);
}

function capture() {
  output('capture: ' + this.v);
}

function bubble() {
  output('bubble: ' + this.v);
}

for (let i = 0; i < eles.length; i++) {
  eles[i].style.border = "1px solid red";
  eles[i].style.width = "100px";
  eles[i].style.padding = "10px";
  eles[i].v = (i + 1);
  eles[i].addEventListener('click', capture, true);
  eles[i].addEventListener('click', bubble, false);
}
