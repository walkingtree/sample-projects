import React from "react";
import Card from "../UI/Card";

//Renders unordered list of users wrapped inside the Card
const UsersList = (props) => {
  return <Card className={classes.users}></Card>;
};

export default UsersList;
