import React, { useState } from "react";

// Renders a form to take users input. This form is wrapped inside a Card.
// Does basic validations and shows an error modal window if the inputs are invalid
const AddUser = (props) => {
  return <div></div>;
};

export default AddUser;
