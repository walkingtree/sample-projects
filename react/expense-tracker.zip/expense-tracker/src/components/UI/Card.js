import React from 'react';

import './Card.css';

// Card is a wrapper component for Expenses component as props.children