import React from 'react';

import ExpenseItem from './ExpenseItem';
import Card from '../UI/Card';
import './Expenses.css';

//Parent Component for ExpenseItem with Card component wrapper
