import React from 'react';

import './ExpenseDate.css';

// A component that renders a formatted date