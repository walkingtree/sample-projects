import React from "react";

const CartContext = React.createContext({
  items: [],
  total: 0.0,
  addCartItem: () => {},
  removeCartItem: () => {},
});

export default CartContext;

export const CartContextProvider = (props) => {};
