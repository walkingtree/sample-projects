import CartContext from "./cart-context";

//A Cart provider that provides cart data to other components.
//It also holds logic to add or remove items from cart
const defaultCartState = {
  items: [],
  totalAmount: 0,
};


  return (
    <CartContext.Provider value={cartContext}>
      {props.children}
    </CartContext.Provider>
  );
};

export default CartProvider;
