// import React, { useContext, useEffect, useState } from "react";
// import classes from "./HeaderCartButton.module.css";
// import CartIcon from "../Cart/CartIcon";
// import CartContext from "../../store/cart-context";

// Renders the Cart button
// Holds logic for handling the Cart button  
const HeaderCartButton = (props) => {
};

export default HeaderCartButton;
