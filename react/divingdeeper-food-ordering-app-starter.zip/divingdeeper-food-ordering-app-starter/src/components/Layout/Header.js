// import React, {Fragment} from 'react';

// import classes from './Header.module.css';
// import mealImage from '../../assets/meals.jpg';
// import HeaderCartButton from './HeaderCartButton';


//Renders Text, cart button and meals image
// Cart button id in the HeaderCartButton component
const Header = (props) => {
};
export default Header;