// import { Fragment } from "react";
// import ReactDOM from "react-dom";

// import classes from "./Modal.module.css";


//Defines a modal and overlay and renders it through portal

const Modal = (props) => {
};

export default Modal;
