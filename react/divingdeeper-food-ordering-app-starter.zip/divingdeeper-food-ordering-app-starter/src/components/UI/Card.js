// import React from 'react';
// import classes from './Card.module.css';

//Renders a Card wrapper for components
const Card = (props) => {
}
export default Card;
