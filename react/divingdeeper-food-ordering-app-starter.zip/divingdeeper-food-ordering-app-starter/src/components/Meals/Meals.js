// import React, {Fragment} from 'react';
// import AvailableMeals from './AvailableMeals';
// import MealsSummary from './MealsSummary';

//Renders MealSummary and AvailableMeals components
const Meals = () => {
};
export default Meals;