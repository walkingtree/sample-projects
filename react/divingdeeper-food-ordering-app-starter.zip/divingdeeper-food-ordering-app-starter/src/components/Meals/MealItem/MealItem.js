// import { useContext } from "react";

// import MealItemForm from "./MealItemForm";
// import classes from "./MealItem.module.css";
// import CartContext from "../../../store/cart-context";


//Renders MealItemForm for the dummy meals and handles logic to add selected item to the cart
const MealItem = (props) => {
};

export default MealItem;
