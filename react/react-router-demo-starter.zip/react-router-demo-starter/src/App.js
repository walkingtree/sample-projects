import { Fragment } from "react";
import MainHeader from "./components/MainHeader";
import Welcome from "./pages/Welcome";
import Products from "./pages/Products";

function App() {
  return (
    <Fragment>
      <header>
        <MainHeader></MainHeader>
      </header>
      <main>
        <Welcome></Welcome>
        <Products></Products>
      </main>
    </Fragment>
  );
}

export default App;
