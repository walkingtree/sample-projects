import React from "react";
import classes from "./MainHeader.module.css";

const MainHeader = () => {
  return (
    <div className={classes.header}>
      <nav>
        <ul>
          <li>Welcome</li>
          <li>Products</li>
        </ul>
      </nav>
    </div>
  );
};
export default MainHeader;
