const ProductDetail = () => {
  return (
    <section>
      <h1>Product Detail</h1>
    </section>
  );
};

export default ProductDetail;
