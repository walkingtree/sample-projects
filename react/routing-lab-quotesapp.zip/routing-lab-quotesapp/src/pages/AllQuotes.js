const AllQuotes = () => {
  return <h1>All Quotes Page</h1>;
};

export default AllQuotes;
