// Retrieving all the button elements







// function makeSound(key) to play the correct sound based on key 








// Handling the keydown event on buttons





