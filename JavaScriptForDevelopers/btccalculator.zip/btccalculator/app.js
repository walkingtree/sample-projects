// 1. Selecting elements







// 2. Defining function / handler








// 3. Calculating profit / loss when all fields are valid
  








// 4. Writing the result to the UI in the given format
  
