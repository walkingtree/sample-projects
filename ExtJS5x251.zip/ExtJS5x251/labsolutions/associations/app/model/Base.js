Ext.define('Associations.model.Base', {
	extend: 'Ext.data.Model',
	schema: {
		namespace: 'Associations.model'
	}
});