Ext.define('Buttons.view.main.MainModel', {
	extend: 'Ext.app.ViewModel',
	alias: 'viewmodel.main',

	data: {

	},
	formulas: {

	},
	stores: {

	}

});