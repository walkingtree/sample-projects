Ext.define('Buttons.view.main.MainController', {
	extend: 'Ext.app.ViewController',
	alias: 'controller.main'
});