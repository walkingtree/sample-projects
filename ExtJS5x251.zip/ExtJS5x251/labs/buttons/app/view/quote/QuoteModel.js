Ext.define('Buttons.view.quote.QuoteModel', {
	extend: 'Ext.app.ViewModel',
	alias: 'viewmodel.quote',
	
	data: {
		quote: {
			text: 'Choose a quote.',
			align: 'left'
		}
	}

});