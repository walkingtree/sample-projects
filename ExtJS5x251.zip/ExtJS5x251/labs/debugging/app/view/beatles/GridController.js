Ext.define('Beatles.view.beatles.GridController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.beatles-grid'
    
});
