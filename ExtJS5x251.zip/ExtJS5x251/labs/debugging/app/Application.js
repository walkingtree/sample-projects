Ext.define('Beatles.Application', {
    extend: 'Ext.app.Application',
    
    name: 'Beatles'

});
