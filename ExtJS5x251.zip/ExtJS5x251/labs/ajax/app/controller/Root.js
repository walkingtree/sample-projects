/**
 * The main application controller. This is a good place to handle things like routes.
 */
Ext.define('Ajax.controller.Root', {
    extend: 'Ext.app.Controller'
});
