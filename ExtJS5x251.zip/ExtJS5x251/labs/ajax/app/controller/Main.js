Ext.define('Ajax.controller.Main', {
    extend: 'Ext.app.Controller'
});
