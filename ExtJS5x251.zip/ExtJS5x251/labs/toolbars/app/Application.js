Ext.define('Toolbars.Application', {
    extend: 'Ext.app.Application',

    name: 'Toolbars'

});