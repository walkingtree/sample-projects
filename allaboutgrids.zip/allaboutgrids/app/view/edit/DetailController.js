Ext.define('ArticleReader.view.edit.DetailController', {
	extend: 'Ext.app.ViewController',

	requires: [
		"ArticleReader.view.edit.Window"
	],

	alias: 'controller.edit-detail',
	
	onEditClick: function(button) {
		this.getView().add(Ext.create({
			xtype: 'editwindow',
			title: 'Edit Window',
			autoShow: true
		}));
	},

	onSaveClick: function(button) {
		this.getViewModel().get('post').commit();
		var post = this.getViewModel().get('post');
		this.lookupReference('editWindow').close();
	},

	onCancelClick: function(button) {
		this.getViewModel().get('post').reject();
		this.lookupReference('editWindow').close();
	}

});