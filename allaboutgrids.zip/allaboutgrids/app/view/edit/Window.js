Ext.define("ArticleReader.view.edit.Window",{
    extend: "Ext.window.Window",
    
    xtype: 'editwindow',

    reference: 'editWindow',
 
    resizable: false,
    bodyPadding: 8,
    modal: true,
    layout: 'fit',

    items: [{
        xtype: 'form',
        reference: 'form',
        modelValidation: true,
        layout: 'form',

        defaults: {
            labelWidth: '15%',
            xtype: 'textareafield',
            anchor: '100%'
        },
        
        items: [
        {
            fieldLabel: 'Title',
            name: 'title',
            maxGrow: 80,
            bind: {
                value: '{post.title}'
            }
        }, {
            fieldLabel: 'Summary',
            name: 'summary',
            maxGrow: 120,
            bind: {
                value: '{post.excerpt}'
            }
        }],
        buttons: [{
            text: 'Save',
            formBind: true,
            handler: 'onSaveClick'
        }, {
            text: 'Cancel',
            handler: 'onCancelClick'
        }]
    }]
});