Ext.define("ArticleReader.view.edit.Detail", {
    extend: "Ext.panel.Panel",

    requires: ['ArticleReader.view.edit.DetailController'],

    controller: 'edit-detail',

    xtype: 'editdetail',

    scrollable: true,
    collapseMode: 'mini',
    border: true,
    bodyPadding: 6,

    tbar: [{
        text: 'Edit',
        iconCls: 'x-fa fa-edit',
        margin: 5,
        handler: 'onEditClick'
    }],

    tpl: [
        '<tpl if="this.isData(values)">',
        '<tpl for=".">',
        '<div class="category font12">{category}</div>',
        '<hr>',
        '<div style = "font-size: 22px; margin: 15px; line-height: 1.5; height: 85px"><b>{title}</b></div>',
        '</br>',
        '<img class="wp-thumbnail" src="http://www.gravatar.com/avatar/{email}"  alt="author"  width="90px" height="90px";>',
        '<p class="published-footer" style="position: relative;top: 30px;">published on <span class="font14">{[this.formatDate(values)]}</span></p>',
        '</br>',
        '</br>',
        '</br>',
        '<div style = "margin: 15px; font-size: 15px;" class="lineht18">{excerpt}</div>',
        '</tpl>',
        '</tpl>', {
            isData: function(data) {
                return !Ext.Object.isEmpty(data);
            },
            formatDate: function(values) {
                var date = Ext.util.Format.date(values.date, 'jS M,  Y');
                return date;
            }
        }
    ]
});