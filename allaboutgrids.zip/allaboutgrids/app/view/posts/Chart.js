Ext.define('ArticleReader.view.posts.Chart', {
	extend: 'Ext.panel.Panel',
	requires: [
		'Ext.chart.series.Bar',
		'Ext.chart.axis.Numeric',
		'Ext.chart.axis.Category',
		'Ext.chart.interactions.ItemHighlight',
		'Ext.chart.interactions.PanZoom',
		'Ext.chart.CartesianChart'
	],

	xtype: 'postschart',

	itemId: 'chart',
	
	items: [{
		xtype: 'cartesian',
		reference: 'chart',
		width: '100%',
		height: 460,

		bind: {
			store: '{hitCounts}',
			hidden: '{!post}'
		},

		animation: true,

		interactions: [{
			type: 'panzoom',
			zoomOnPanGesture: true
		}],

		legend: true,
		
    	insetPadding: {
			top: 20,
			left: 40,
			right: 40,
			bottom: 20
		},

		innerPadding: {
			left: 5
		},

		axes: [{
			type: 'numeric',
			position: 'left',
			minimum: 0,
			maximum: 100,
			title: {
				text: 'Hits',
				font: 'normal 18px Georgia, serif',
				fillStyle: 'RoyalBlue'
			},
			label: {
				fillStyle: 'black',
				font: '12px Georgia, serif'
			}
		}, {
			type: 'category',
			position: 'bottom',
			titleMargin: 10,
			title: {
				text: 'Month',
				fillStyle: 'RoyalBlue',
				font: 'normal 18px Georgia, serif'
			},
			label: {
				fillStyle: 'black',
				font: '12px Georgia, serif',
				rotate: {
                    degrees: -45
                }
			}
		}],

		series: {
			type: 'bar',
			xField: 'month',
			yField: 'hitcount',
			title: ['Hit Count'],
			highlight: {
				strokeStyle: 'black',
				fillStyle: 'gold'
			},
			style: {
				minGapWidth: 10,
				fillStyle: 'SlateGray'
			},
			tooltip: {
				trackMouse: true,
				style: {
					fontStyle: 'italic',
					border: 'thin solid black'
				},
				renderer: function(toolTip, record, ctx) {
					var month = record.get('month');
					var count = record.get('hitcount');
					var views = (count > 1) ? ' views' : ' view';
					toolTip.setHtml(month + ': ' + count + views);
				}
			}
		}
	}]
});