Ext.define('ArticleReader.view.posts.TabPanel', {
  extend: 'Ext.tab.Panel',
  requires: [
    'ArticleReader.view.posts.View',
    'ArticleReader.view.posts.Chart'
  ],

  xtype: 'poststabpanel',

  reference:'poststabpanel',

  items: [{
    title: 'View',
    xtype: 'postsview',
    bind: {
      store: '{posts}',
      selection: '{post}'
    }
  }, {
    title: 'Stats',
    xtype: 'postschart'
  }]
});