 Ext.define('ArticleReader.view.PostFilter', {
     extend: 'Ext.toolbar.Toolbar',
     
     xtype: 'postfilter',

     items: [{
             xtype: 'combobox',
             reference: 'feedCombo',

             fieldLabel: 'Select Category',

             value: 'All Posts',
             displayField: 'title',
             queryMode: 'local',
             padding: 5,
             bind: {
                 store: '{feeds}',
                 selection: '{feed}'
             }
         }]
 });