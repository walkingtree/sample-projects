Ext.define('ArticleReader.view.main.Main', {
    extend: 'Ext.panel.Panel',
    xtype: 'app-main',
    requires: [
        'Ext.plugin.Viewport',
        'ArticleReader.view.main.MainController',
        'ArticleReader.view.main.MainModel',
        'ArticleReader.view.Banner',
        'ArticleReader.view.posts.TabPanel',
        'ArticleReader.view.PostFilter',
        "ArticleReader.view.edit.Detail"
    ],
    controller: 'main',
    viewModel: {
        type: 'main'
    },
    layout: 'border',
    dockedItems: [{
        xtype: 'banner',
        dock: 'top'
    }, {
        xtype: 'postfilter',
        dock: 'top'
    }],
    items: [{
        region: 'center',
        xtype: 'poststabpanel'
    }, {
        region: 'east',
        xtype: 'editdetail',
        width: 380,
        title: 'Details',
        bind: {
            data: {
                bindTo: '{post}',
                deep: true
            },
            collapsed: '{!post}'
        }
    }]
});