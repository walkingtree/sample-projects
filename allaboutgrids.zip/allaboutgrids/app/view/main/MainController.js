Ext.define('ArticleReader.view.main.MainController', {
	extend: 'Ext.app.ViewController',

	requires: ['Ext.draw.sprite.Sprite'],
	
	alias: 'controller.main',

	initViewModel: function(vm) {
		var me = this;
		vm.bind('{post}', this.setText, this);
		vm.bind('{feed}', this.clearPost, this);
	},

	clearPost: function() {
		this.getViewModel().set('post', null);
	},

	setText: function(post) {
		if (post != null) {
			var data = post.data;
			var title=data.title;
			var surface = this.lookupReference('chart').getSurface();
			if(surface) {
				surface.remove('anim');
			};
			var sprite = {
				id: 'anim',
				type: 'text',
				text: title,
				fillStyle: 'Red',
				fontSize: 16,
				x: 5,
				y: 17
			};
			surface.add(sprite);
			surface.renderFrame();
		}
	},

	rendererFunc: function(val, metaData, rec, rowIndex, colIndex, store, view){
            var tags = rec.get('tagTitleCount');
            var tips = "";

            for( var i = 0; i < tags.length; i++){
                var title = tags[i].title;
                var count = tags[i].count;
                tip = title + ":&nbsp" + count + ",&nbsp";
                tips = tips + tip;
            };

            var toolTip = tips.substr(0,((tips.length)-6));

            if(tags.length > 0) {
            	metaData.tdAttr = 'data-qtip=' + toolTip; 
            } else {
            	metaData.tdCls = 'no-tags';
            }
    }
});



