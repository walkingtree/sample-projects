Ext.define('ArticleReader.view.main.MainModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.main',
    requires: [
        'ArticleReader.model.Feed',
        'ArticleReader.model.Post',
        'ArticleReader.model.HitCount',
    ],

    data: {
        feed: null,
        post: null
    },

    stores: {
        feeds: {
            model: 'ArticleReader.model.Feed',
            autoLoad: true
        },

        posts: {
            model: 'ArticleReader.model.Post',
            autoLoad: true,
            /*filters: [{
                category: '{feed.id}',
                id: 'cat',
                filterFn: function(rec) {
                    if (this.category === 100) {
                        return true; // Treat 100 for all records
                    }
                    var c = rec.data.categories[0].id;
                    if (c === this.category) {
                        return true;
                    }

                }
            }],
            listeners: {
                load: 'onFirstLoad',
                single: true
            }*/

        },

        hitCounts: {
            model: 'ArticleReader.model.HitCount',
            autoLoad: {
                url: "http://touchdemo.walkingtree.in/Training/?json=get_article_monthwisehits&id={post.id}"
            }
        }
    }
});