Ext.define('ArticleReader.model.Feed', {
    extend: 'Ext.data.Model',

    fields: [{
    	name: 'id',
    	type: 'int'
    },{
    	name: 'title',
    	type: 'string'
    }],
    
    proxy: {
        type: 'ajax',
        url: 'resources/data/Feeds.json',
        reader: {
            type: 'json',
            rootProperty: 'categories'
        }
    }
 });