Ext.define('ArticleReader.model.HitCount', {
	extend: 'Ext.data.Model',
	proxy: {
		type: 'jsonp',
		reader: {
			type: 'json',
			rootProperty: 'monthwisehits'
		}
	}
});