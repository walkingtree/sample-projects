Ext.define('ArticleReader.model.Post', {
    extend: 'Ext.data.Model',
    fields: [{
        name: 'id',
        type: 'int',
        mapping: 'id'
    },{
        name: 'title',
        type: 'string',
        mapping: 'title'
    }, {
        name: 'catId',
        type: 'int',
        mapping: 'categories[0].id'
    }, {
        name: 'category',
        type: 'string',
        mapping: 'categories[0].title',
        validators: [{
            type: 'presence'
        }]
    }, {
        name: 'excerpt',
        type: 'string',
        validators: [{
            type: 'presence'
        }]
    }, {
        name: 'firstName',
        type: 'string',
        mapping: 'author.first_name'
    }, {
        name: 'lastName',
        type: 'string',
        mapping: 'author.last_name'
    }, {
        name: 'authorName',
        type: 'string',
        calculate: function(data) {
            return data.firstName + " " + data.lastName;
        }
    }, {
        name: 'date',
        type: 'date'
    }, {
        name: 'email',
        type: 'string',
        mapping: 'author.email'
    }, {
        name: 'tags',
        type: 'auto'
    }, {
        name: 'tagCount',
        calculate: function(data) {
            var values = [];
            var tags = data.tags;
            for (var i = 0; i < tags.length; i++) {
                var count = tags[i].post_count;
                values.push(count);
            }
            return values;
        }
    }, {
        name: 'tagTitleCount',
        calculate: function(data) {
            var titles = [];
            var tags = data.tags;
            for (var i = 0; i < tags.length; i++) {
                var title = tags[i].slug;
                var count = tags[i].post_count;
                titles.push({
                    'title': title,
                    'count': count
                });
            }
            return titles;
        }
    }],

    proxy: {
        type: 'ajax',
        url: 'resources/data/Posts.json',
        reader: {
            type: 'json',
            rootProperty: 'posts'
        }
    }
});