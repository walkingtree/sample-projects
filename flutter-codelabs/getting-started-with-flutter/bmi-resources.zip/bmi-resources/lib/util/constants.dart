import 'dart:ui';
import 'package:flutter/material.dart';

const kPrimaryColor = const Color(0xFF344955);
const kPrimaryColorDark = const Color(0xFF232F34);
const kPrimaryColorLight = const Color(0xFF4A6572);
const kAccentColor = const Color(0xFFF9AA33);
const kScaffoldBackgroundColor = const Color(0xffF5F5F6);

const kHeadline6Style = const TextStyle(
  fontSize: 28.0,
  fontWeight: FontWeight.bold,
  fontFamily: 'Source Sans Pro',
);

const kBodyText1Style = const TextStyle(
  fontSize: 17.0,
  fontWeight: FontWeight.w700,
  fontFamily: 'Quicksand',
);

const kButtonTextStyle = const TextStyle(
  color: Colors.white,
  fontSize: 26.0,
  fontWeight: FontWeight.w600,
  fontFamily: 'Source Sans Pro',
);

const kTextHintStyle = const TextStyle(
    fontSize: 16.0, fontFamily: 'Quicksand', fontWeight: FontWeight.w700);

const kBmiResultTextStyle = TextStyle(
  color: Colors.blueGrey,
  fontSize: 22.0,
  fontWeight: FontWeight.bold,
  fontFamily: 'Quicksand',
);

const kBmiTextStyle = const TextStyle(
    color: kPrimaryColorDark,
    fontSize: 80.0,
    fontWeight: FontWeight.w600,
    fontFamily: 'Source Sans Pro',
    textBaseline: TextBaseline.alphabetic);

const kBmiInterpretationTextStyle = const TextStyle(
  color: kPrimaryColorDark,
  fontSize: 18.0,
  fontWeight: FontWeight.w600,
  fontFamily: 'Source Sans Pro',
);
