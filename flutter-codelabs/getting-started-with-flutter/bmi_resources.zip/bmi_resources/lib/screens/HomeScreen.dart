import 'package:bmi_calculator/util/constants.dart';
import 'package:flutter/material.dart';
import '../widgets/bmi_result_widget.dart';

class HomeScreen extends StatelessWidget {
  String _userName = '';

  // Set the user name
  void userNameChangedHandler(String newName) {
       try {
          _userName = newName;
        } catch (exception) {
          _userName = '';
        }
   }

  // Builder method to render Textfield widget for name
  Widget _builderUserName() {
    return TextField(
      keyboardType: TextInputType.text,
      decoration: InputDecoration(
        hintText: "Name",
        hintStyle: kTextHintStyle,
      ),
      onChanged: userNameChangedHandler,
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kScaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text(
          "BMI Calculator",
          style: kHeadline6Style,
        ),
        backgroundColor: kPrimaryColorDark,
      ),
      body: Column(
         children: <Widget>[
          BmiResult(),
           _builderUserName(),
        ],
      ),
    );
  }
}
