import 'package:bmi_calculator/util/constants.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class BmiResult extends StatelessWidget {
  final String userName;
  final String bmiResult;
  final String resultText;
  final String interpretation;

  const BmiResult({
    this.userName,
    this.bmiResult,
    this.resultText,
    this.interpretation,
  });

  // Widget builderImageContainer(String resultText) {
  //   return Container(
  //     height: 50,
  //     width: 50,
  //     decoration: BoxDecoration(
  //       image: DecorationImage(
  //         image: AssetImage((resultText == 'normal')
  //             ? 'assets/images/happy.gif'
  //             : (resultText == 'overweight')
  //                 ? 'assets/images/exercise.gif'
  //                 : 'assets/images/unhappy.gif'),
  //         fit: BoxFit.cover,
  //         ),
  //
  //       shape: BoxShape.circle,
  //     ),
  //   );
  // }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 230,
      color: kAccentColor,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Text(
              (userName != '' && resultText != '')
                  ? "$userName, you are $resultText"
                  : '',
              style: kBmiResultTextStyle,
            ),
            Text(
              (bmiResult != '') ? "$bmiResult" : "BMI",
              style: kBmiTextStyle,
            ),
            // Row(
            //   mainAxisAlignment: MainAxisAlignment.center,
            //   children: [
            //     Text(
            //       (bmiResult != '') ? "$bmiResult" : "BMI",
            //       style: kBmiTextStyle,
            //      ),
            //     SizedBox(width: 20.0),
            //     (userName != '' && resultText != '')
            //         ? builderImageContainer(resultText)
            //         : Container(),
            //   ],
            // ),
            Text(
              (interpretation != '') ? '$interpretation' : '',
              style: kBmiInterpretationTextStyle,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
      // ),
    );
  }
}
