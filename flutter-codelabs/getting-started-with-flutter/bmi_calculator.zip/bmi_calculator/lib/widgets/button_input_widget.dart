import 'package:bmi_calculator/util/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter/rendering.dart';

class ButtonInput extends StatelessWidget {
  final Function onTapHandler;
  final IconData icon;

  ButtonInput({this.icon, this.onTapHandler});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTapHandler,
      borderRadius: BorderRadius.circular(12),
      highlightColor: kAccentColor.withOpacity(0.3),
      splashColor: kAccentColor.withOpacity(0.7),
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: kAccentColor,
        ),
        child: Icon(
          icon,
          size: 26.0,
          color: kPrimaryColorDark,
        ),
      ),
    );
  }
}
