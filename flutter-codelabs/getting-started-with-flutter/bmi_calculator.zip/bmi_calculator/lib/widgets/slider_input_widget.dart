import 'package:bmi_calculator/util/constants.dart';
import 'package:flutter/material.dart';

class SliderInput extends StatelessWidget {
  final double inputValue;
  final String inputText;
  final Function onChangedHandler;
  final double min;
  final double max;

  const SliderInput({
    @required this.min,
    @required this.max,
    @required this.inputValue,
    @required this.inputText,
    @required this.onChangedHandler,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Text(
              "$inputText",
              style: kBodyText1Style,
            ),
            Text(
              "${inputValue.toStringAsFixed(2)}",
              style: kBodyText1Style,
            ),
          ],
        ),
        //Slider
        Slider(
          min: min,
          max: max,
          value: inputValue,
          activeColor: kAccentColor,
          inactiveColor: kPrimaryColorLight,
          onChanged: onChangedHandler,
        ),
      ],
    );
  }
}
