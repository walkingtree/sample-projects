import 'package:bmi_calculator/util/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../widgets/slider_input_widget.dart';
import '../widgets/bmi_result_widget.dart';
import '../widgets/button_input_widget.dart';
import '../calculate_bmi.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  double _height = 120;
  double _weight = 70;
  String _userName = '';
  int _age = 26;
  String _bmiResult = '';
  String _resultText = '';
  String _interpretation = '';

  // Set the user name
  void userNameChangedHandler(String newName) {
    setState(
      () {
        try {
          _userName = newName;
        } catch (exception) {
          _userName = '';
        }
      },
    );
  }

  //Set height input by the slider
  void _heightChangedHandler(double newValue) {
    setState(
      () {
        _height = newValue;
      },
    );
  }

  // Set weight input by the slider
  void _weightChangedHandler(double newValue) {
    setState(
      () {
        _weight = newValue;
      },
    );
  }

  // Set age when plus icon is tapped
  void _incrementAgeHandler() {
    setState(
      () {
        _age++;
      },
    );
  }

  // Set age when minus icon is tapped
  void _decrementAgeHandler() {
    setState(
      () {
        _age--;
      },
    );
  }

  // To calculate BMI when 'CALCULATE' button is clicked
  void _calculateBmiHandler() {
    //To create instance of CalculatBmi class which has the application logic
    CalculatBmi calc = CalculatBmi(height: _height, weight: _weight);
    setState(
      () {
        _bmiResult = calc.getBmi();
        _resultText = calc.getResult();
        _interpretation = calc.getInterpretation();
      },
    );
  }

  // Builder method to render Textfield widget for name
  Widget _builderUserName() {
    return TextField(
      keyboardType: TextInputType.text,
      decoration: InputDecoration(
        hintText: "Name",
        hintStyle: kTextHintStyle,
      ),
      onChanged: userNameChangedHandler,
    );
  }

  // Calculate button
  Widget _builderCalculateButton() {
    return RaisedButton(
      elevation: 5.0,
      color: kPrimaryColorDark,
      child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: const Text(
          'CALCULATE',
          style: kButtonTextStyle,
        ),
      ),
      onPressed: _calculateBmiHandler,
    );
  }

  // Builder method to render Age buttons
  Widget _builderUserAge() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        const Text("Age(years)", style: kBodyText1Style),
        Row(
          children: <Widget>[
            //Reusable age button widget
            ButtonInput(
              icon: Icons.remove,
              onTapHandler: _decrementAgeHandler,
            ),
            SizedBox(width: 10),
            Text("$_age", style: kBodyText1Style),
            SizedBox(width: 10),
            //Reusable age button widget
            ButtonInput(
              icon: Icons.add,
              onTapHandler: _incrementAgeHandler,
            ),
          ],
        )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: kScaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text(
          "BMI Calculator",
          style: kHeadline6Style,
        ),
        backgroundColor: kPrimaryColorDark,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          BmiResult(
            userName: _userName,
            bmiResult: _bmiResult,
            resultText: _resultText,
            interpretation: _interpretation,
          ),
          Expanded(
            flex: 5,
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Builder method to render Name Textfield
                  _builderUserName(),
                  // Builder method to render Age buttons
                  _builderUserAge(),
                  //Widget to render height slider
                  SliderInput(
                    min: 60,
                    max: 220,
                    inputValue: _height,
                    inputText: 'Height(cm)',
                    onChangedHandler: _heightChangedHandler,
                  ),
                  //Widget to render weight slider
                  SliderInput(
                    min: 20,
                    max: 120,
                    inputValue: _weight,
                    inputText: 'Weight(kg)',
                    onChangedHandler: _weightChangedHandler,
                  ),
                ],
              ),
            ),
          ),
          //Button to calculate BMI
          _builderCalculateButton(),
        ],
      ),
    );
  }
}
