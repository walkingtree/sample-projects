import 'package:bmi_calculator/util/constants.dart';
import 'package:flutter/material.dart';
import './screens/HomeScreen.dart';

void main() => runApp(BmiCalculator());

class BmiCalculator extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomeScreen(),
    );
  }
}
