//import 'dart:ui';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Color(0xFF00213F),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              CircleAvatar(
                radius: 50.0,
                backgroundImage: AssetImage('assets/images/sigmatek.jpg'),
              ),
              Text(
                'SIGMATEK',
                style: TextStyle(
                  color: Color(0xFFD3D6D7),
                  fontFamily: 'OpenSans',
                  fontSize: 44.0,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 8,
                ),
              ),
              // // Row(
              // //   mainAxisAlignment: MainAxisAlignment.center,
              // //   children: [
              // //     Text(
              // //       'SIGMA',
              // //       style: TextStyle(
              // //         fontFamily: 'OpenSans',
              // //         fontSize: 44.0,
              // //         color: Colors.red,
              // //         fontWeight: FontWeight.w900,
              // //         letterSpacing: 5,
              // //       ),
              // //     ),
              // //     Text(
              // //       'TEK',
              // //       style: TextStyle(
              // //         fontFamily: 'OpenSans',
              // //         fontSize: 44.0,
              // //         color: Colors.blue.withOpacity(0.8),
              // //         fontWeight: FontWeight.w900,
              // //         letterSpacing: 5,
              // //       ),
              // //     ),
              // //   ],
              // // ),
              SizedBox(height: 80),
              Text(
                'Sunny Kukhreja',
                style: TextStyle(
                  fontFamily: 'Quicksand',
                  color: Color(0xFFD3D6D7),
                  fontSize: 26.0,
                  letterSpacing: 2,
                  fontWeight: FontWeight.w900,
                ),
              ),
              SizedBox(height: 5.0),
              Text(
                'CEO & Co-founder',
                style: TextStyle(
                    fontFamily: 'OpenSans',
                    color: Color(0xFFBCC2CC),
                    fontSize: 26.0,
                    fontWeight: FontWeight.w400,
                    letterSpacing: 2.5,
                    wordSpacing: 10),
              ),
              SizedBox(
                height: 50.0,
                width: 150.0,
              ),
              Card(
                margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
               // color: Color(0xFFD3D6D7),
               child: ListTile(
                  leading: Icon(
                    Icons.phone,
                    color: Color(0xFF00213F),
                  ),
                  title: Text(
                    '+14 222 443 332',
                    style: TextStyle(
                      color: Color(0xFF00213F),
                      fontFamily: 'Quicksand',
                      fontSize: 20.0,
                    ),
                  ),
                ),
              ),
              Card(
                color: Color(0xFFD3D6D7),
                margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
                child: ListTile(
                  leading: Icon(
                    Icons.email,
                    color: Color(0xFF00213F),
                  ),
                  title: Text(
                    'sk@gmail.com',
                    style: TextStyle(
                      fontSize: 20.0,
                      color: Color(0xFF00213F),
                      fontFamily: 'Quicksand',
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
