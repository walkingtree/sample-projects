package com.example.my_theming_app_starter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
