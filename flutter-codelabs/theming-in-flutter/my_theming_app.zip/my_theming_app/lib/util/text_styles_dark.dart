import 'package:flutter/material.dart';
import 'color_palette_dark.dart';

const kHeadline6TextStyle = TextStyle(
  fontSize: 26.0,
  fontWeight: FontWeight.w700,
);

const kHeadline5TextStyle = TextStyle(
  fontSize: 24.0,
  color: kDarkThemeWhite,
);

const kHeadline4TextStyle = TextStyle(
  fontSize: 24.0,
  fontWeight: FontWeight.bold,
  color: kDarkThemeWhite,
);

const kHeadline3TextStyle = TextStyle(
  fontSize: 24.0,
  fontWeight: FontWeight.w600,
);


const kHeadline2TextStyle = TextStyle(
    fontSize: 30.0,
    fontWeight: FontWeight.w800,
    letterSpacing: 1.2,
    color: kDarkThemeWhite,
);

const kHeadline1TextStyle = TextStyle(
  color: kDarkThemeBlack,
  fontSize: 42.0,
  fontWeight: FontWeight.w800,
);


const kBodyText1Style = TextStyle(
  fontSize: 28,
  fontWeight: FontWeight.w800,
  color: kDarkThemeWhite,
);


const kBodyText2Style = TextStyle(
  color: kDarkThemeSubHeading,// Color(0xff818387),
  fontSize: 22.0,
  fontWeight: FontWeight.bold,
  fontFamily: 'Quicksand',
  letterSpacing: 1.2,
  wordSpacing: 1.5,
);

const kCaptionStyle = TextStyle(
  color: kDarkThemePrimary,
  fontSize: 18.0,
  fontWeight: FontWeight.w600,
);

const kButtonTextStyle = TextStyle(
  fontSize: 24.0,
  fontWeight: FontWeight.w800,
  letterSpacing: 1.2,
);

const kTextHintStyle = TextStyle(
  fontSize: 22.0,
  fontFamily: 'QuickSand',
);

const kErrorTextStyle = TextStyle(
  fontSize: 20.0,
  fontWeight: FontWeight.bold,
  fontFamily: 'QuickSand',
);

const kDialogContentStyle = TextStyle(
  color: kDarkThemeWhite,
  fontSize: 18.0,
  fontWeight: FontWeight.w600,
);