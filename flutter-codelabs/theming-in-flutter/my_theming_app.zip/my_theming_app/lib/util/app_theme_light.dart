import 'package:flutter/material.dart';
import '../util/text_styles.dart';
import 'color_palette.dart';

class AppThemeLight {
  AppThemeLight();

  static ThemeData buildAppThemeLight() {
    final ThemeData base = ThemeData.light();

    return base.copyWith(
     brightness: Brightness.light,
     primaryColor: kLightThemePrimary,
     primaryColorLight: kLightThemePrimaryLight,
     primaryColorDark: kLightThemePrimaryDark,
     accentColor: kLightThemeSecondary,
     scaffoldBackgroundColor: kLightThemeScaffoldBackground,

     colorScheme: base.colorScheme.copyWith(
       onPrimary: kLightThemeOnPrimary,
       secondary: kLightThemeSecondary,
       onSecondary: kLightThemeOnPrimary,
       surface: kLightThemeSurface,
       onSurface: kLightThemeWhite,
       background: kLightThemeWhite,
       onBackground: kLightThemeBlack,
     ),

      textTheme: _buildBmiTextTheme(base.textTheme),

      inputDecorationTheme: base.inputDecorationTheme.copyWith(
        contentPadding: EdgeInsets.all(20.0),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(
          color: kLightThemePrimary,
            width: 1.5,
          ),
          borderRadius: BorderRadius.circular(50),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: kLightThemePrimary,
            width: 1.5,
          ),
          borderRadius: BorderRadius.circular(50),
         ),
        hintStyle: kTextHintStyle,
      ),

      //By default takes the primaryColor and TextTheme headline6 style
      appBarTheme: base.appBarTheme.copyWith(
        textTheme: base.textTheme.copyWith(
          headline6: kHeadline6TextStyle,
        ),
        iconTheme: base.iconTheme.copyWith(
          color: kLightThemeWhite
        ),
      ),

      //Override the default FloatingActionButton theme
      floatingActionButtonTheme: base.floatingActionButtonTheme.copyWith(
        backgroundColor: kLightThemeSecondary,
        foregroundColor: kLightThemeWhite,
        elevation: 5.0,
      ),

      //Override the default Button theme
      buttonTheme: base.buttonTheme.copyWith(
        buttonColor: kLightThemePrimary,
        //Color to start filling the Buttons when pressed.
        splashColor: kLightThemePrimaryDark,
      ),

      //Override the default Dialog Theme
      dialogTheme: base.dialogTheme.copyWith(
        titleTextStyle: kHeadline4TextStyle,
        contentTextStyle: kDialogContentStyle,
      ),

      //Override the default Button theme
      dividerTheme: base.dividerTheme.copyWith(
        color: kLightThemeBlackOpaque,
        thickness: 1,
      ),

      //Override for the default SnackBar Theme
      snackBarTheme: base.snackBarTheme.copyWith(
        backgroundColor: kLightThemeErrorColor,
        contentTextStyle: kErrorTextStyle,
      ),

      // //Override for the default Card theme
      cardTheme: base.cardTheme.copyWith(
        color: kLightThemeSurface,
        elevation: 20.0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20.0),
        ),
      ),

      // Overiding the icon theme
      iconTheme: base.iconTheme.copyWith(
        color: kLightThemePrimary,
        size: 8.0,
      ),

    );
   }

  // Method to create and return the text styles
  static _buildBmiTextTheme(TextTheme base) {
    return base
        .copyWith(
          headline6: kHeadline6TextStyle,
          headline5: kHeadline5TextStyle,
          headline4: kHeadline4TextStyle,
          headline3: kHeadline3TextStyle,
          headline2: kHeadline2TextStyle,
          headline1: kHeadline1TextStyle,
          bodyText1: kBodyText1Style,
          bodyText2: kBodyText2Style,
          button: kButtonTextStyle,
          caption: kCaptionStyle,
        )
        .apply(
          // This will override and apply to all.
          fontFamily: 'OpenSans',
        );
  }
}
