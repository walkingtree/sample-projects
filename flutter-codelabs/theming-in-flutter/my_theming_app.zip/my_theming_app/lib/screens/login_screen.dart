import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../util/color_palette.dart';
import '../util/color_palette_dark.dart';
import '../screens/meals_screen.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  final emailTextController = TextEditingController();
  final pwdTextController = TextEditingController();

  @override
  void dispose() {
    emailTextController.dispose();
    pwdTextController.dispose();
    super.dispose();
  }

  void signInHandler() {
    String email = emailTextController.text;
    String pwd = pwdTextController.text;
    if (email == 'user@gmail.com' && pwd == '1234') {
      Navigator.pushNamed(context, '/categoryScreen');
    } else {
      showInSnackBar('Sorry! Enter correct credentials.');
    }
  }

  void showInSnackBar(value) {
    _scaffoldKey.currentState.showSnackBar(
      new SnackBar(
        content: Text(
          value,
        ),
        duration: Duration(seconds: 1),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final Brightness brightness = Theme.of(context).brightness;
    final themeData = Theme.of(context);
    return Scaffold(
      key: _scaffoldKey,
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Stack(
              alignment: Alignment.bottomCenter,
              children: [
                // Image container
                Container(
                  height: 340,
                  child: Image(
                    fit: BoxFit.fill,
                    image: AssetImage(
                      'assets/images/food.jpg',
                    ),
                  ),
                ),
                // Welcome text container
                Container(
                  height: 65,
                  width: double.infinity,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: (brightness == Brightness.light)
                          ? [
                        kLightThemeGradientBeginColor,
                        kLightThemeGradientEndColor,
                      ]
                          : [
                        kDarkThemeGradientBeginColor,
                        kDarkThemeGradientEndColor,
                      ],
                    ),
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20.0),
                      topRight: Radius.circular(20.0),
                    ),
                  ),
                  child: Text(
                    'Welcome!',
                    style: themeData.textTheme.headline1,
                  ),
                )
              ],
            ),
            Expanded(
              // Main Container
              child: Container(
                alignment: Alignment.center,
                color: themeData.colorScheme.background,
                padding: EdgeInsets.only(
                  top: 0,
                  left: 30,
                  right: 30,
                  bottom: mediaQuery.viewInsets.bottom + 10,
                ),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // Simple text
                      Container(
                        width: double.infinity,
                        height: 35,
                        alignment: Alignment.center,

                        child: Text(
                          "Time to cook, let's Sign In",
                          style: themeData.textTheme.bodyText2,
                        ),
                      ),

                      SizedBox(
                        height: 30,
                      ),

                      //Email Input
                      TextField(
                        controller: emailTextController,
                        style: themeData.textTheme.headline5,
                        decoration: InputDecoration(
                          hintText: "Email",
                        ),
                      ),

                      SizedBox(
                        height: 10,
                      ),

                      //Password Input
                      TextField(
                        controller: pwdTextController,
                        obscureText: true,
                        decoration: InputDecoration(
                          hintText: "Password",
                        ),
                      ),

                      SizedBox(
                        height: 5,
                      ),

                      //Container for Forgot Password
                      Container(
                        height: 24,
                        alignment: Alignment.center,
                        child: Text(
                          "Forgot password?",
                          style: themeData.textTheme.caption,
                        ),
                      ),

                      SizedBox(
                        height: 25,
                        width: double.infinity,
                      ),

                      // Sign In Button
                      RaisedButton(
                        padding: EdgeInsets.all(14.0),
                        textColor: themeData.colorScheme.onPrimary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(50.0),
                        ),
                        child: Text(
                          "SIGN IN",
                        ),
                        onPressed: signInHandler,
                      ),

                      SizedBox(
                        height: 3,
                        width: double.infinity,
                      ),

                      // First time Sign In
                      RichText(
                        textAlign: TextAlign.center,
                        text: TextSpan(
                          text: "It's your first time? ",
                          style: themeData.textTheme.caption.copyWith(
                            color: themeData.colorScheme.onBackground,
                            fontFamily: 'Quicksand',
                          ),
                          children: <TextSpan>[
                            TextSpan(
                              text: 'Sign up',
                              style: themeData.textTheme.caption,
                            ),
                          ],
                        ),
                      ),

                      SizedBox(
                        height: 10,
                        width: double.infinity,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
