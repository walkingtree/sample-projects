import 'package:flutter/material.dart';
import '../models/meal.dart';
import '../data.dart';

class MealsScreen extends StatelessWidget {
  static const routeName = '/mealsScreen';

  @override
  Widget build(BuildContext context) {
    // Extract the arguments from the current ModalRoute settings and cast
    // them as Map - same as passed with pushNamed().
    final Map<String, String> args = ModalRoute.of(context).settings.arguments;

    final Brightness brightness = Theme.of(context).brightness;
    final ThemeData themeData = Theme.of(context);

    // Traverses through the 'MEALS' list and creates a new list 'meals' with each 'Meal' object.
    // [] brackets are used to access property of a Map object.
    final List<Meal> meals = MEALS.where((mealData) {
      return mealData.category == args['catId'];
    }).toList();

    // Called when any meal is tapped.
    // pushNamed takes 3 arguments - context, route name and optional arguments.
    onMealTapHandler(index) async {
      String isFav = await Navigator.pushNamed<dynamic>(
        context,
        '/mealDetailScreen',
        arguments: <String, String>{
          'mealId': meals[index].id,
        },
      );
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text(
              'Meal',
            ),
            content: Text(
              isFav,
            ),
          );
        },
      );
    }

    return Scaffold(
      appBar: AppBar(),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Container to define height of Card for headings
          Container(
            height: 180,

            //Card for shape and styling while showing headings
            child: Card(
              margin: EdgeInsets.only(top: 8, bottom: 40),
              shadowColor: themeData.primaryColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    //Text for main heading
                    Text(
                      'Select Meal',
                      textAlign: TextAlign.center,
                      style: themeData.textTheme.bodyText1,
                    ),

                    SizedBox(height: 15),

                    // Text for subheading
                    Text(
                      'Help you to cook healthy food',
                      style: themeData.textTheme.bodyText2,
                      textAlign: TextAlign.center,
                      softWrap: false,
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            //Main Container with give top rounded corners. It holds all the meal content.
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20.0),
                  topRight: Radius.circular(20.0),
                ),
                color: themeData.colorScheme.background,
              ),
              child: ListView.separated(
                itemCount: meals.length,
                itemBuilder: (context, index) {
                  return InkWell(
                    // Tap on any meal takes to the detail screen
                    onTap: () {
                      onMealTapHandler(index);
                    },
                    child: Stack(
                      alignment: Alignment.centerLeft,
                      children: <Widget>[
                        //Container to give height to the card
                        Container(
                          margin: EdgeInsets.only(left: 90),
                          width: double.infinity,
                          height: 100.0,

                          //Card for each meal
                          child: Card(
                            color: (brightness == Brightness.light)
                                ? themeData.colorScheme.background
                                : themeData.colorScheme.surface,
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  top: 8.0,
                                  bottom: 8.0,
                                  left: 25.0,
                                  right: 25.0),

                             child: Theme(
                                data: themeData.copyWith(
                                  textTheme: themeData.textTheme.copyWith(
                                    bodyText2:
                                    themeData.textTheme.bodyText2.copyWith(
                                      color: themeData.primaryColor,
                                    ),
                                    caption:
                                    themeData.textTheme.caption.copyWith(
                                      color: themeData.colorScheme.onBackground,
                                    ),
                                  ),
                                ),
                                // Column to show vertical content of each card
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  children: <Widget>[
                                    // To show meal title
                                    Text(
                                      meals[index].title,
                                      style: themeData.textTheme.bodyText2,
                                      softWrap: false,
                                      overflow: TextOverflow.ellipsis,
                                    ),

                                    //Row to show horizontal content for meal gluten content
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            // Icon for text
                                            Icon(Icons.brightness_1),

                                            SizedBox(width: 5),

                                            //Gluten/Not Gluten content
                                            Text(
                                              (meals[index].isGlutenFree)
                                                  ? 'Gluten Free'
                                                  : 'Has Gluten',
                                              style:
                                                  themeData.textTheme.caption,
                                            ),
                                          ],
                                        ),

                                        SizedBox(width: 30),

                                        //Row to show horizontal content for vegetarian / non vegetarian meal
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                            // Icon for text
                                            Icon(Icons.brightness_1),

                                            SizedBox(width: 5),

                                            //Vegetarian/Non vegetarian content
                                            Text(
                                              (meals[index].isVegetarian)
                                                  ? 'Veg'
                                                  : 'Non-Veg',
                                              style:
                                                  themeData.textTheme.caption,
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),

                          // To show meal image
                          child: CircleAvatar(
                            backgroundImage: NetworkImage(
                              meals[index].imageUrl,
                            ),
                            radius: 50.0,
                          ),
                        ),
                      ],
                    ),
                  );
                },
                separatorBuilder: (context, int) {
                  return SizedBox(
                    height: 8.0,
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
