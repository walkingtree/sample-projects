import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../widgets/main_drawer.dart';
import '../models/category.dart';
import '../data.dart';
import '../screens/meals_screen.dart';

class CategoryScreen extends StatelessWidget {
  static const routeName = '/categoryScreen';

  // Traverses through the 'CATEGORIES' list and creates a new list 'categories' with each 'Category' object.
  final List<Category> categories = CATEGORIES.map((catData) {
    return catData;
  }).toList();

  @override
  Widget build(BuildContext context) {
    // Called when any category is tapped.
    // pushNamed takes 3 arguments - context, route name and optional arguments.
    onCategoryTapHandler(index) {
      Navigator.pushNamed(
        context,
        '/mealsScreen',
        arguments: <String, String>{
          'catId': categories[index].id,
        },
      );
    }

    return Scaffold(
      //appBar: AppBar(),
      appBar: AppBar(),
         // Creates a side drawer
      drawer: MainDrawer(),

      body: Column(
        children: [
          Container(
            height: 180,
            // Card to show heading
            child: Card(
              margin: EdgeInsets.only(top: 8, bottom: 40),
              shadowColor: Theme.of(context).primaryColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: Padding(
                padding: const EdgeInsets.all(15.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Main heading text
                    Text(
                      'Select Cuisine',
                      style: Theme.of(context).textTheme.bodyText1,
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: 15),
                    //Sub heading text
                    Text(
                      'Create your masterpieces',
                      style: Theme.of(context).textTheme.bodyText2,
                      textAlign: TextAlign.center,
                      softWrap: false,
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            // Main Container
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20.0),
                  topRight: Radius.circular(20.0),
                ),
                color: Theme.of(context).colorScheme.background,
              ),

              child: GridView.builder(
              padding: const EdgeInsets.all(25),
              itemCount: categories.length,
              itemBuilder: (context, index) {
                return Column(
                  children: [
                    InkWell(
                      // Card to give elevation and shape to the category image container
                      child: Card(
                        margin: EdgeInsets.all(0),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(
                            Radius.circular(20),
                          ),
                        ),

                        // Container for giving height and shape to the category image
                        child: Container(
                          height: 170,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            image: DecorationImage(
                              image: NetworkImage((categories[index].imageUrl)),
                              fit: BoxFit.fill,
                            ),
                          ),
                        ),
                      ),
                      // Tap on any category takes to to the meal screen
                      onTap: () {
                        onCategoryTapHandler(index);
                      },
                    ),

                    SizedBox(height: 5),

                    // Text to show Category title
                    Text(
                      categories[index].title,
                      style: Theme.of(context).textTheme.headline2,
                      textAlign: TextAlign.center,
                    ),
                  ],
                );
              },
              gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                maxCrossAxisExtent: 200,
                childAspectRatio: 3 / 5,
                crossAxisSpacing: 30,
                mainAxisSpacing: 10,
              ),
            ),
          ),
          ),
        ],
      ),


    );
  }
}
