import 'package:flutter/material.dart';
import '../util/color_palette.dart';
import '../util/color_palette_dark.dart';
import '../models/meal.dart';
import '../data.dart';

class MealDetailScreen extends StatefulWidget {
  static const routeName = '/mealDetailScreen';

  final Function _toggleFavorite;
  final Function _isMealFavorite;

  MealDetailScreen(this._toggleFavorite, this._isMealFavorite);

  @override
  _MealDetailScreenState createState() => _MealDetailScreenState();
}

class _MealDetailScreenState extends State<MealDetailScreen> {
  bool isFavorite = false;

  @override
  Widget build(BuildContext context) {
    // Extract the arguments from the current ModalRoute settings and cast
    // them as Map - same as passed with pushNamed().
    final Map<String, String> args = ModalRoute.of(context).settings.arguments;

    final ThemeData themeData = Theme.of(context);
    final Brightness brightness = Theme.of(context).brightness;

    // Traverses through the 'MEALS' list and returns a Meal object that matches the mealId.
    // [] brackets are used to access property of a Map object.
    final Meal mealDetail = MEALS.firstWhere(
      (meal) {
        return (meal.id == args['mealId']);
      },
    );

    isFavorite = widget._isMealFavorite(mealDetail.id);

    return WillPopScope(
      onWillPop: () async {
        return false;
      },
      child: Scaffold(
        //User goes back to Meals Screen via this button
        floatingActionButton: FloatingActionButton(
          //Icon the FAB
          child: Icon(
            Icons.arrow_back,
            size: 32,
          ),
          onPressed: () {
            (isFavorite)
                ? Navigator.pop(
                    context, '${mealDetail.title} is marked favorite!')
                : Navigator.pop(
                    context, '${mealDetail.title} is nothing great!');
          },
        ),
        body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Stack(
                alignment: Alignment.topRight,
                children: [
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      //Container to show the Meal Image
                      Container(
                        height: 300,
                        width: double.infinity,
                        child: Image.network(
                          mealDetail.imageUrl,
                          fit: BoxFit.fill,
                        ),
                      ),

                      //Play Icon on the Meal Image
                      IconButton(
                        icon: Icon(
                          Icons.play_arrow,
                          size: 80.0,
                          color: themeData.colorScheme.onSurface,
                        ),
                        onPressed: () {},
                      ),
                    ],
                  ),

                  //Container with black tanslucent color to show meal title on topleft of image
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(
                        Radius.circular(50.0),
                      ),
                      color: (brightness == Brightness.light)
                          ? kLightThemeBlackOpaque
                          : kDarkThemeBlackOpaque,
                    ),
                    margin: EdgeInsets.only(top: 40.0),
                    padding: EdgeInsets.all(5),
                    child: Text(
                      mealDetail.title,
                      style: themeData.textTheme.caption.copyWith(
                        color: themeData.colorScheme.onSurface,
                      ),
                    ),
                  ),
                ],
              ),

              //Main container with rounded top corners to show duration, complexity and favorite icon
              Container(
                height: 60,
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(15.0),
                    topRight: Radius.circular(15.0),
                  ),
                  color: themeData.primaryColor,
                ),

                //Row to show duration, complexity and favorite icon
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Row(
                      children: [
                        // Text for duration
                        Text(
                          mealDetail.duration,
                          style: themeData.textTheme.headline3,
                        ),
                      ],
                    ),

                    GestureDetector(
                      child: Icon(
                        (isFavorite) ? Icons.favorite : Icons.favorite_border,
                        size: 35,
                        color: (brightness == Brightness.light)
                            ? kLightThemeRed
                            : kDarkThemeRed,
                      ),
                      onTap: () {
                        setState(
                          () {
                            if (isFavorite == true) {
                              isFavorite = false;
                            } else {
                              isFavorite = true;
                            }
                            widget._toggleFavorite(mealDetail.id);
                          },
                        );
                      },
                    ),

                    // Text to show recipe complexity
                    Text(
                      mealDetail.complexity,
                      style: themeData.textTheme.headline3,
                    ),
                  ],
                ),
              ),
              Expanded(
                //Main Container for content below the image
                child: Container(
                  color: themeData.colorScheme.background,
                  child: Column(
                    children: [
                      //Container for heading
                      Container(
                        margin: EdgeInsets.symmetric(vertical: 10),
                        //Heading for the ingredients
                        child: Text(
                          'Ingredients',
                          style: themeData
                              .textTheme
                              .headline4
                              .copyWith(fontSize: 28),
                        ),
                      ),

                      //Line below the heading
                      Divider(
                        indent: 60,
                        endIndent: 60,
                      ),

                      SizedBox(height: 20),

                      //Container for giving height and background to the card for showing ingredients
                      Container(
                        height: 200,
                        child: ListView.builder(
                          itemCount: mealDetail.ingredients.length,
                          itemBuilder: (ctx, index) => Theme(
                            data: themeData.copyWith(
                              cardTheme: themeData.cardTheme.copyWith(
                                    color: themeData
                                        .colorScheme
                                        .background,
                                    elevation: .5,
                                  ),
                            ),

                            //Card to hold ingredients
                            child: Card(
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                  vertical: 5,
                                  horizontal: 10,
                                ),
                                child: Text(
                                  mealDetail.ingredients[index],
                                  style: themeData
                                      .textTheme
                                      .bodyText2
                                      .copyWith(
                                        letterSpacing: .5,
                                        wordSpacing: .5,
                                      ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
