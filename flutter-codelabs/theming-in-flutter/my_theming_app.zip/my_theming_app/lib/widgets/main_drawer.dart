import 'package:flutter/material.dart';
import '../util/color_palette.dart';
import '../util/color_palette_dark.dart';

class MainDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: <Widget>[
          Container(
            padding: EdgeInsets.only(
              left: 20.0,
              top: 40.0,
            ),
            width: double.infinity,
            height: 100.0,
            color: Theme.of(context).primaryColor,
            child: Text(
              'Meals App',
              style: Theme.of(context).textTheme.headline6,
            ),
          ),
          SizedBox(
            height: 20.0,
          ),
          InkWell(
            onTap: () {
              Navigator.pushNamed(
                context,
                '/categoryScreen',
              );
            },
            child: ListTile(
              leading: Icon(
                Icons.home,
                color: Theme.of(context).primaryColor,
                size: 30.0,
              ),
              title: Text(
                'Categories',
                style: Theme.of(context).textTheme.bodyText2.copyWith(
                  color: Theme.of(context).colorScheme.onBackground,
                ),
              ),
            ),
          ),
          SizedBox(height: 20.0, child: Divider()),
          InkWell(
            onTap: () {
              Navigator.pushNamed(
                context,
                '/favoriteMealsScreen',
              );
            },
            child: ListTile(
              leading: Icon(
                Icons.favorite,
                color: Theme.of(context).primaryColor,
                size: 30.0,
              ),
              title: Text(
                'Favorites',
                style: Theme.of(context).textTheme.bodyText2.copyWith(
                  color: Theme.of(context).colorScheme.onBackground,
                ),
              ),
            ),
          ),
          SizedBox(height: 20.0, child: Divider()),
          InkWell(
            onTap: () {},
            child: ListTile(
              leading: Icon(
                Icons.power_settings_new,
                color: Theme.of(context).primaryColor,
                size: 30.0,
              ),
              title: Text(
                'Log Out',
                style: Theme.of(context).textTheme.bodyText2.copyWith(
                  color: Theme.of(context).colorScheme.onBackground,
                ),
              ),
            ),
          ),
          SizedBox(
            height: 20.0,
            child: Divider(),
          ),
        ],
      ),
    );
  }
}
