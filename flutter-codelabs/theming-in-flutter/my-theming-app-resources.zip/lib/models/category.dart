import 'package:flutter/material.dart';

// Create a class that contains a customizable category with id and title.
class Category {
  final String id;
  final String title;
  final String imageUrl;

  const Category({
    @required this.id,
    @required this.title,
    @required this.imageUrl
  });
}


