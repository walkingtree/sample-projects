import 'package:flutter/material.dart';

// Create a class that contains a customizable meal with id, category, title,
// complexity, imageUrl, ingredients, isGlutenFree, isVegetarian, total time
class Meal {
  final String id;
  final String category;
  final String title;
  final String complexity;
  final String imageUrl;
  final List<String> ingredients;
  final bool isGlutenFree;
  final bool isVegetarian;
  final String duration;
  
  const Meal({
    @required this.id,
    @required this.category,
    @required this.title,
    @required this.complexity,
    @required this.imageUrl,
    @required this.ingredients,
    @required this.isGlutenFree,
    @required this.isVegetarian,
    @required this.duration
  });
}

