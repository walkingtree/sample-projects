import 'package:flutter/material.dart';

class MainDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: <Widget>[
          //Container for header
          Container(
            padding: EdgeInsets.only(
              left: 20.0,
              top: 40.0,
            ),
            width: double.infinity,
            height: 100.0,

            //Text for heading
            child: Text(
              'Meals App',
           ),
          ),

          SizedBox(
            height: 20.0,
          ),

          InkWell(
            onTap: () {
              Navigator.pushNamed(
                context,
                '/categoryScreen',
              );
            },
            child: ListTile(
              //Icon and Text
              leading: Icon(
                Icons.home,
                size: 30.0,
              ),

              title: Text(
                'Categories',
              ),
            ),
          ),

          SizedBox(height: 20.0, child: Divider(),),

          //Icon and Text
          InkWell(
            onTap: () {
              Navigator.pushNamed(
                context,
                '/favoriteMealsScreen',
              );
            },
            child: ListTile(
              leading: Icon(
                Icons.favorite,
                size: 30.0,
              ),

              title: Text(
                'Favorites',
               ),
            ),
          ),

          SizedBox(height: 20.0, child: Divider(),),

          //Icon and Text
          InkWell(
            onTap: () {},
            child: ListTile(
              leading: Icon(
                Icons.power_settings_new,
                size: 30.0,
              ),
              title: Text(
                'Log Out',
              ),
            ),
          ),

          SizedBox(
            height: 20.0,
            child: Divider(),
          ),
        ],
      ),
    );
  }
}
