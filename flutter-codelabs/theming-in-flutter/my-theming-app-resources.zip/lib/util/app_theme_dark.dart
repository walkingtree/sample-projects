import './text_styles_dark.dart';
import 'package:flutter/material.dart';
import 'color_palette_dark.dart';

// Theme override for the light theme
class AppThemeDark {
  AppThemeDark();

  static ThemeData buildAppThemeDark() {
    final ThemeData base = ThemeData.dark();

    return base.copyWith(
      brightness: Brightness.dark,

      primaryColor: kDarkThemePrimary,
      primaryColorLight: kDarkThemePrimaryLight,
      primaryColorDark: kDarkThemePrimaryDark,

      accentColor: kDarkThemeSecondary,

      scaffoldBackgroundColor: kDarkThemeScaffoldBackground,

      colorScheme: base.colorScheme.copyWith(
        onPrimary: kDarkThemeOnPrimary,
        onSecondary: kDarkThemeOnSecondary,
        surface: kDarkThemeSurface,
        onSurface: kDarkThemeWhite,
        background: kDarkThemeBlack,
        onBackground: kDarkThemeWhite,
      ),

      textTheme: _buildBmiTextTheme(base.textTheme),

      // By default takes the primaryColor and TextTheme headline6 style
      appBarTheme: base.appBarTheme.copyWith(
        textTheme: base.textTheme.copyWith(
          headline6: kHeadline6TextStyle, //This is default
        ),
        iconTheme:  base.iconTheme.copyWith(
          color: kDarkThemeWhite,
        ),
      ),

      floatingActionButtonTheme: base.floatingActionButtonTheme.copyWith(
        backgroundColor: kDarkThemeSecondary,
        elevation: 5.0,
      ),

      //Override for the default Card theme
      cardTheme: base.cardTheme.copyWith(
        color: kDarkThemeSurface,
        elevation: 20.0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20.0),
        ),
      ),

      //Override for the default SnackBar Theme
      snackBarTheme: base.snackBarTheme.copyWith(
        backgroundColor: kDarkThemeErrorColor,
        contentTextStyle: kErrorTextStyle,
      ),

      //Override for the default Dialog Theme
      dialogTheme: base.dialogTheme.copyWith(
        backgroundColor: kDarkThemeSecondaryDark,
        titleTextStyle: kHeadline4TextStyle,
        contentTextStyle: kDialogContentStyle,
      ),

      dividerTheme: base.dividerTheme.copyWith(
        color: kDarkThemeSecondaryDark,
        thickness: 1,
      ),

      buttonTheme: base.buttonTheme.copyWith(
        buttonColor: kDarkThemePrimary,
        //Color to start filling the Buttons when pressed.
        splashColor: kDarkThemePrimaryDark,
      ),

      // Override for the default Textfield style
      inputDecorationTheme: base.inputDecorationTheme.copyWith(
        contentPadding: EdgeInsets.all(20.0),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: kDarkThemeSecondaryDark,
            width: 1.5,
          ),
          borderRadius: BorderRadius.circular(50),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: kDarkThemeSecondaryDark,
            width: 1.5,
          ),
          borderRadius: BorderRadius.circular(50),
        ),
        hintStyle: kTextHintStyle,
      ),

      // Overiding the icon theme
      iconTheme: base.iconTheme.copyWith(
        color: kDarkThemePrimary,
        size: 8.0,
      ),
    );
  }

  // Method to create and return the text styles
  static _buildBmiTextTheme(TextTheme base) {
    return base
        .copyWith(
      headline6: kHeadline6TextStyle,
      headline5: kHeadline5TextStyle,
      headline4: kHeadline4TextStyle,
      headline3: kHeadline3TextStyle,
      headline2: kHeadline2TextStyle,
      headline1: kHeadline1TextStyle,
      bodyText1: kBodyText1Style,
      bodyText2: kBodyText2Style,
      button: kButtonTextStyle,
      caption: kCaptionStyle,
    ).apply(
      // This will override and apply to all.
      fontFamily: 'OpenSans',
    );
  }
}
