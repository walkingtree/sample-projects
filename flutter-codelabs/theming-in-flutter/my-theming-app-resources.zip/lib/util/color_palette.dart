import 'package:flutter/material.dart';

// Light Theme Colors
const kLightThemeBlack = Colors.black87;
const kLightThemeBlackOpaque = Colors.black38;
const kLightThemeWhite = Colors.white;
const kLightThemeRed = Colors.red;

const kLightThemePrimary = const Color(0xffFF932F);
const kLightThemePrimaryLight = const Color(0xffffc460);
const kLightThemePrimaryDark = const Color(0xffc66400);

const kLightThemeSecondary = const Color(0xff6a4f4b);
const kLightThemeSecondaryLight = const Color(0xff8b6b61);

const kLightThemeSurface = const Color(0xff3e2723);

const kLightThemeOnPrimary = Colors.white;
const kLightThemeOnSecondary = Colors.black;

const kLightThemeSubHeading = Color(0xff818387);

const kLightThemeScaffoldBackground = const Color(0xff050000);

const kLightThemeGradientEndColor = const Color(0xff818387);
const kLightThemeGradientBeginColor = Colors.white;

const kLightThemeErrorColor = Color(0xffb71c1c);

const kLightThemeButtonTextColor = Colors.white;
