//Dark Theme Colors
import 'package:flutter/material.dart';

const kDarkThemeBlack = Colors.black87;
const kDarkThemeBlackOpaque = Colors.black38;
const kDarkThemeWhite = Colors.white;
const kDarkThemeRed = Color(0xffb71c1c);

const kDarkThemePrimary = const Color(0xffCA5552);
const kDarkThemePrimaryDark= const Color(0xFFBB3D39);
const kDarkThemePrimaryLight = const Color(0xffCF6461);

const kDarkThemeSecondary = const Color(0xff9e9e9e);
const kDarkThemeSecondaryDark = const Color(0xff616161);
const kDarkThemeSecondaryLight = const Color(0xffbdbdbd);

const kDarkThemeOnPrimary = Colors.white;
const kDarkThemeOnSecondary = Colors.black;

const kDarkThemeSurface = const Color(0xff263238);

const kDarkThemeScaffoldBackground = Colors.black;

const kDarkThemeGradientEndColor = const Color(0xff263238);
const kDarkThemeGradientBeginColor = const Color(0xffc3c9c9);

const kDarkThemeSubHeading= Color(0xff818387);

const kDarkThemeErrorColor = Color(0xffb71c1c);

const kDarkThemeButtonTextColor = Colors.white;

