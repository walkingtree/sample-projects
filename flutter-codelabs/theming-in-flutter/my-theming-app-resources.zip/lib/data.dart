import './models/category.dart';
import './models/meal.dart';

const CATEGORIES = const [
  Category(
    id: 'c1',
    title: 'Indian',
    imageUrl:'http://mypullzone.9vexd6dl53at.maxcdn-edge.com/wp-content/uploads/2016/08/kadai-paneer-gravy-recipe-step-by-step-instructions.jpg',
  ),
  Category(
    id: 'c2',
    title: 'Italian',
    imageUrl: 'http://www.thewholegang.org/wp-content/uploads/2011/10/Chicken-Penne1-300x201.jpg',
  ),
  Category(
    id: 'c3',
    title: 'German',
    imageUrl: 'https://cdn.pixabay.com/photo/2018/03/31/19/29/schnitzel-3279045_1280.jpg',
  ),
   Category(
    id: 'c4',
    title: 'French',
     imageUrl: 'https://cdn.pixabay.com/photo/2014/08/07/21/07/souffle-412785_1280.jpg',
  ),
  Category(
    id: 'c5',
    title: 'Quick & Easy',
    imageUrl: 'https://cdn.pixabay.com/photo/2018/04/09/18/26/asparagus-3304997_1280.jpg',
  ),
  Category(
    id: 'c6',
    title: 'Exotic',
    imageUrl: 'https://cdn.pixabay.com/photo/2017/05/01/05/18/pastry-2274750_1280.jpg',
  ),
  Category(
    id: 'c7',
    title: 'Breakfast',
    imageUrl: 'https://cdn.pixabay.com/photo/2018/07/10/21/23/pancake-3529653_1280.jpg',
  )
];

const MEALS = const [
  Meal(
    id: 'm1',
    category: 'c1',
    title: 'Quick Paneer',
    complexity: 'Simple',
    imageUrl:
        'http://mypullzone.9vexd6dl53at.maxcdn-edge.com/wp-content/uploads/2016/08/kadai-paneer-gravy-recipe-step-by-step-instructions.jpg',
    ingredients: [
      '4 Tomatoes',
      '2 Tablespoon Oil',
      '2 Onions',
      '2 Tablespoon Ginger-Garlic Paste',
      '250g Paneer',
      'Spices',
      '4 Tablespoon Cream'
    ],
    isGlutenFree: true,
    isVegetarian: true,
      duration: '10 mins'
  ),
  Meal(
    id: 'm2',
    category: 'c2',
    title: 'Spaghetti',
     complexity: 'Challenging',
    imageUrl:
        'https://prods3.imgix.net/images/articles/2017_08/Non-Feature-Wok-Fried-Spaghetti-Arrabbiata-Shrimp-Recipe.jpg?auto=format%2Ccompress&dpr=2.63&ixjsv=2.2.3&q=38&w=370',
    ingredients: [
      '4 Tomatoes',
      '1 Tablespoon of Olive Oil',
      '1 Onion',
      '5 Olives',
      '5 Jalepenos',
      '250g Spaghetti',
      'Spices',
      'Cheese (optional)'
    ],
    isGlutenFree: false,
    isVegetarian: true,
      duration: '20 mns'
  ),
  Meal(
    id: 'm3',
    category: 'c2',
    title: 'Penne in Red Sauce',
      complexity: 'Hard',
    imageUrl:
        'http://www.thewholegang.org/wp-content/uploads/2011/10/Chicken-Penne1-300x201.jpg',
    ingredients: [
      '1 Cup Tomato Puree',
      '1 Tablespoon of Olive Oil',
      '1 Onion',
      '1 Red and 1 Yellow Bell Pepper',
      '50g Mushrooms',
      '50g Broccoli',
      '400g Penne',
      'Spices',
      'Cheese (optional)'
    ],
    isGlutenFree: false,
    isVegetarian: true,
      duration: '30 mins'
  ),
  Meal(
    id: 'm4',
    category: 'c1',
    title: 'Lachha Paratha',
      complexity: 'Challenging',
    imageUrl:
        'https://tse4.mm.bing.net/th?id=OIP.SH_0FkZd8fZaSThKvmF3hQAAAA&pid=Api&P=0&w=220&h=166',
    ingredients: ['4 Tablespoon Oil', 'Spices', 'All purpose flour'],
    isGlutenFree: false,
    isVegetarian: true,
      duration: '60 mins'
  ),
  Meal(
    id: 'm5',
    category: 'c5',
    title: 'Toast Hawaii',
    complexity: 'Simple',
    imageUrl:
    'https://cdn.pixabay.com/photo/2018/07/11/21/51/toast-3532016_1280.jpg',
    ingredients: [
      '1 Slice White Bread',
      '1 Slice Ham',
      '1 Slice Pineapple',
      '1-2 Slices of Cheese',
      'Butter'
    ],
    isGlutenFree: false,
    isVegetarian: false,
      duration: '10 mins'
  ),
  Meal(
    id: 'm6',
    category: 'c5',
    title: 'Classic Hamburger',
     complexity: 'Simple',
    imageUrl:
    'https://cdn.pixabay.com/photo/2014/10/23/18/05/burger-500054_1280.jpg',
    ingredients: [
      '300g Cattle Hack',
      '1 Tomato',
      '1 Cucumber',
      '1 Onion',
      'Ketchup',
      '2 Burger Buns'
    ],
    isGlutenFree: false,
    isVegetarian: false,
    duration: '45 mins'
  ),
  Meal(
    id: 'm7',
    category: 'c3',
    title: 'Wiener Schnitzel',
    complexity: 'Challenging',
    imageUrl:
    'https://cdn.pixabay.com/photo/2018/03/31/19/29/schnitzel-3279045_1280.jpg',
    ingredients: [
      '8 Veal Cutlets',
      '4 Eggs',
      '200g Bread Crumbs',
      '100g Flour',
      '300ml Butter',
      '100g Vegetable Oil',
      'Salt',
      'Lemon Slices'
    ],
    isGlutenFree: false,
    isVegetarian: false,
    duration: '60 mins',
  ),
  Meal(
    id: 'm8',
    category: 'c5',
    title: 'Salad with Smoked Salmon',
    complexity: 'Simple',
    imageUrl:
    'https://cdn.pixabay.com/photo/2016/10/25/13/29/smoked-salmon-salad-1768890_1280.jpg',
    ingredients: [
      'Arugula',
      'Lamb\'s Lettuce',
      'Parsley',
      'Fennel',
      '200g Smoked Salmon',
      'Mustard',
      'Balsamic Vinegar',
      'Olive Oil',
      'Salt and Pepper'
    ],
    isGlutenFree: true,
    isVegetarian: true,
    duration: '15 mins'
  ),
  Meal(
    id: 'm9',
    category:'c6',
    title: 'Delicious Orange Mousse',
    complexity: 'Hard',
    imageUrl:
    'https://cdn.pixabay.com/photo/2017/05/01/05/18/pastry-2274750_1280.jpg',
    ingredients: [
      '4 Sheets of Gelatine',
      '150ml Orange Juice',
      '80g Sugar',
      '300g Yoghurt',
      '200g Cream',
      'Orange Peel',
    ],
    isGlutenFree: true,
    isVegetarian: true,
    duration: '240 mins',
  ),

  Meal(
    id: 'm10',
    category: 'c7',
    title: 'Pancakes',
    complexity: 'Simple',
    imageUrl:
    'https://cdn.pixabay.com/photo/2018/07/10/21/23/pancake-3529653_1280.jpg',
    ingredients: [
      '1 1/2 Cups all-purpose Flour',
      '3 1/2 Teaspoons Baking Powder',
      '1 Teaspoon Salt',
      '1 Tablespoon White Sugar',
      '1 1/4 cups Milk',
      '1 Egg',
      '3 Tablespoons Butter, melted',
    ],
    isGlutenFree: true,
    isVegetarian: true,
    duration: '20 mins',
  ),

  Meal(
    id: 'm11',
    category: 'c1',
    title: 'Creamy Indian Chicken Curry',
    complexity: 'Challenging',
    imageUrl:
    'https://cdn.pixabay.com/photo/2018/06/18/16/05/indian-food-3482749_1280.jpg',
    ingredients: [
      '4 Chicken Breasts',
      '1 Onion',
      '2 Cloves of Garlic',
      '1 Piece of Ginger',
      '4 Tablespoons Almonds',
      '1 Teaspoon Cayenne Pepper',
      '500ml Coconut Milk',
    ],
    isGlutenFree: true,
    isVegetarian: false,
    duration: '35 mins',
  ),
  Meal(
    id: 'm12',
    category: 'c4',
    title: 'Chocolate Souffle',
    complexity: 'Hard',
    imageUrl:
    'https://cdn.pixabay.com/photo/2014/08/07/21/07/souffle-412785_1280.jpg',
    ingredients: [
      '1 Teaspoon melted Butter',
      '2 Tablespoons white Sugar',
      '2 Ounces 70% dark Chocolate, broken into pieces',
      '1 Tablespoon Butter',
      '1 Tablespoon all-purpose Flour',
      '4 1/3 tablespoons cold Milk',
      '1 Pinch Salt',
      '1 Pinch Cayenne Pepper',
      '1 Large Egg Yolk',
      '2 Large Egg Whites',
      '1 Pinch Cream of Tartar',
      '1 Tablespoon white Sugar',
    ],
    isGlutenFree: true,
    isVegetarian: true,
    duration: '45 mins',
  ),
  Meal(
    id: 'm13',
    category: 'c5',
    title: 'Asparagus Salad with Cherry Tomatoes',
    complexity: 'Simple',
    imageUrl:
    'https://cdn.pixabay.com/photo/2018/04/09/18/26/asparagus-3304997_1280.jpg',
    ingredients: [
      'White and Green Asparagus',
      '30g Pine Nuts',
      '300g Cherry Tomatoes',
      'Salad',
      'Salt, Pepper and Olive Oil'
    ],
    isGlutenFree: true,
    isVegetarian: true,
    duration: '30 mins',
  ),
];
