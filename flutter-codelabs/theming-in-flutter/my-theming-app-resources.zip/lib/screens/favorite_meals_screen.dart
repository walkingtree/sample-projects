import 'package:flutter/material.dart';
import '../util/color_palette.dart';
import '../util/color_palette_dark.dart';
import '../models/meal.dart';
import '../widgets/main_drawer.dart';

class FavoriteMealsScreen extends StatelessWidget {
  static const routeName = '/favoriteMealsScreen';

  final List<Meal> favoriteMeals;

  FavoriteMealsScreen(this.favoriteMeals);

  @override
  Widget build(BuildContext context) {
    final Brightness brightness = Theme.of(context).brightness;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Favorite Recipes',
        ),
        centerTitle: true,
      ),
      drawer: MainDrawer(),
      body: (favoriteMeals.isEmpty)
          ? Center(
              //Text when no favorite is marked
              child: Text(
                'You have no favorites!',
              ),
            )
          //Details for meals marked favorites
          : ListView.builder(
              itemBuilder: (ctx, index) {
                return Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // Text for the tile of favorite meal
                      Text(
                        favoriteMeals[index].title,
                        textAlign: TextAlign.center,
                        softWrap: true,
                      ),

                      SizedBox(height: 10),

                      Stack(
                        children: [
                          //Left rounded container
                          Container(
                            height: 200.0,
                            width: 200.0,
                            padding: EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15.0),
                              color: (brightness == Brightness.light)
                                  ? kLightThemeBlack
                                  : kDarkThemeBlack,
                            ),
                            alignment: Alignment.center,
                            child: CircleAvatar(
                              radius: 85.0,
                              backgroundImage: NetworkImage(
                                favoriteMeals[index].imageUrl,
                              ),
                            ),
                          ),

                          Positioned(
                            right: 0.0,
                            left: 185.0,

                            //Right side container for meal details
                            child: Container(
                              height: 220.0,
                              width: double.infinity,
                              padding: EdgeInsets.all(10.0),
                              color: Theme.of(context).primaryColor,

                              //Main content of the container
                              child: Column(
                                children: [
                                  SizedBox(
                                    height: 15,
                                  ),
                                  Row(
                                    children: <Widget>[
                                      Icon(
                                        Icons.brightness_1,
                                      ),
                                      SizedBox(
                                        width: 6,
                                      ),
                                      Text(
                                        (favoriteMeals[index].isGlutenFree)
                                            ? 'Gluten Free'
                                            : 'Has Gluten',
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 7.0,
                                  ),
                                  Row(
                                    children: <Widget>[
                                      Icon(
                                        Icons.brightness_1,
                                      ),
                                      SizedBox(
                                        width: 6,
                                      ),
                                      Text(
                                        (favoriteMeals[index].isVegetarian)
                                            ? 'Veg'
                                            : 'Non-Veg',
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 7.0,
                                  ),
                                  Row(
                                    children: <Widget>[
                                      Icon(
                                        Icons.brightness_1,
                                      ),
                                      SizedBox(
                                        width: 6,
                                      ),
                                      Text(
                                        favoriteMeals[index].complexity,
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 7.0,
                                  ),
                                  Row(
                                    children: <Widget>[
                                      Icon(
                                        Icons.brightness_1,
                                      ),
                                      SizedBox(
                                        width: 6,
                                      ),
                                      Text(
                                        favoriteMeals[index].duration,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          )
                        ],
                      ),
                    ],
                  ),
                );
              },
              itemCount: favoriteMeals.length,
            ),
    );
  }
}
