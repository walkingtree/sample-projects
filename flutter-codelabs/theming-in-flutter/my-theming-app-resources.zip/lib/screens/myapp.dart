import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../models/meal.dart';
import '../data.dart';
import './category_screen.dart';
import './meals_screen.dart';
import './meal_detail_screen.dart';
import './favorite_meals_screen.dart';
import 'login_screen.dart';

class MyApp extends StatefulWidget {
  // To store the favorite meals
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  List<Meal> _favoriteMeals = [];

  void _toggleFavorite(String mealId) {
    final existingIndex =
        _favoriteMeals.indexWhere((meal) => meal.id == mealId);
    if (existingIndex >= 0) {
      setState(() {
        _favoriteMeals.removeAt(existingIndex);
      });
    } else {
      setState(() {
        _favoriteMeals.add(
          MEALS.firstWhere((meal) => meal.id == mealId),
        );
      });
    }
  }

  bool _isMealFavorite(String id) {
    return _favoriteMeals.any((meal) => meal.id == id);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Meals App',
      //Declares all routes needed in the app.
      //Here, the MaterialApp is created with a Map<String, WidgetBuilder>
      // which maps from a route's name to a builder function that will create it.
      routes: <String, WidgetBuilder>{
        '/': (BuildContext context) => LoginScreen(),
        CategoryScreen.routeName: (BuildContext context) => CategoryScreen(),
        MealsScreen.routeName: (BuildContext context) => MealsScreen(),
        MealDetailScreen.routeName: (BuildContext context) =>
            MealDetailScreen(_toggleFavorite, _isMealFavorite),
        FavoriteMealsScreen.routeName: (BuildContext context) =>
            FavoriteMealsScreen(_favoriteMeals),
      },
    );
  }
}
