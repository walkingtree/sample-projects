import 'package:flutter/material.dart';
import './screens/myapp.dart';

void main() => runApp(MyApp());

