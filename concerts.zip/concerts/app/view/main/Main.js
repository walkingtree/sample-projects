Ext.define('Concerts.view.main.Main', {
    extend: 'Ext.panel.Panel',
    requires: [
      'Concerts.view.Grid'
    ],
    xtype: 'main',
    layout: 'border',
    title: 'Concerts in Iceland',
    items: [{
      xtype: 'concertsgrid',
      region: 'center',
      store: {
        model: 'Ext.data.Model',
        fields: [{
                name: 'dateOfShow',
                convert: function(dateOfShow) {
                    return new Date(dateOfShow);
                }
        }],
        autoLoad: true,
        proxy: {
          type: 'ajax',
          url: '//apis.is/concerts',
          reader: {
            rootProperty: 'results'
          }
        }
      }
   }]
});
