Ext.application({
	requires:[
		'Concerts.view.main.Main'
	],
    name: 'Concerts',
    mainView: 'Concerts.view.main.Main'
});  